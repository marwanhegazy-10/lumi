import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  ageGroup: text("age_group"),
  onboardingCompleted: boolean("onboarding_completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// User progress table
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  streak: integer("streak").default(0),
  lastActivity: timestamp("last_activity"),
  moodStreak: integer("mood_streak").default(0),
  journalStreak: integer("journal_streak").default(0),
  achievements: jsonb("achievements").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Journal entries table
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  date: timestamp("date").defaultNow(),
  prompt: text("prompt").notNull(),
  content: text("content").notNull(),
  mood: text("mood"),
});

// Mood entries table
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  date: timestamp("date").defaultNow(),
  mood: text("mood").notNull(),
  value: integer("value").notNull(),
  emoji: text("emoji"),
  note: text("note"),
});

// Game completions table
export const gameCompletions = pgTable("game_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  gameId: text("game_id").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
  score: integer("score"),
});

// Schema for inserting users
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  ageGroup: true,
});

// Schema for inserting user progress
export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  streak: true,
  lastActivity: true,
  moodStreak: true,
  journalStreak: true,
  achievements: true,
});

// Schema for inserting journal entries
export const insertJournalEntrySchema = createInsertSchema(journalEntries).pick({
  userId: true,
  prompt: true,
  content: true,
  mood: true,
});

// Schema for inserting mood entries
export const insertMoodEntrySchema = createInsertSchema(moodEntries).pick({
  userId: true,
  mood: true,
  value: true,
  emoji: true,
  note: true,
});

// Schema for inserting game completions
export const insertGameCompletionSchema = createInsertSchema(gameCompletions).pick({
  userId: true,
  gameId: true,
  score: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertGameCompletion = z.infer<typeof insertGameCompletionSchema>;
export type GameCompletion = typeof gameCompletions.$inferSelect;
