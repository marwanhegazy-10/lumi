import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the Mind Boost application
  const apiRouter = express.Router();

  // Health check endpoint
  apiRouter.get("/health", (req, res) => {
    res.status(200).json({ status: "healthy" });
  });

  // Save user progress
  apiRouter.post("/progress", async (req, res) => {
    try {
      const { userId, progress } = req.body;
      
      if (!userId || !progress) {
        return res.status(400).json({ message: "User ID and progress data required" });
      }
      
      // Here we would typically save to a real database
      // For demo purposes, we'll just return success
      res.status(200).json({ 
        message: "Progress saved successfully",
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error saving progress:", error);
      res.status(500).json({ message: "Error saving progress" });
    }
  });

  // Get journaling prompts
  apiRouter.get("/prompts", async (req, res) => {
    try {
      const { ageGroup } = req.query;
      
      if (!ageGroup) {
        return res.status(400).json({ message: "Age group is required" });
      }
      
      // This would typically come from a database
      // For now, just return a simple response
      res.status(200).json({ 
        message: "Prompts retrieved successfully",
        ageGroup,
        // Prompts would normally be returned here
      });
    } catch (error) {
      console.error("Error retrieving prompts:", error);
      res.status(500).json({ message: "Error retrieving prompts" });
    }
  });

  // Register all API routes under /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
