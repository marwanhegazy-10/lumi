import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useMentalApp } from "@/lib/stores/useMentalApp";

// Form validation schema
const formSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type FormData = z.infer<typeof formSchema>;

export default function SignupPage() {
  const navigate = useNavigate();
  const { setName } = useMentalApp();
  const [error, setError] = useState<string | null>(null);
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  const onSubmit = async (data: FormData) => {
    setError(null);
    
    try {
      // In a real app, this would make an API call to create a new account
      console.log("Signup attempt with:", data);
      
      // Mock successful account creation
      // Next step is onboarding, redirect to the first onboarding step
      setName(data.username);
      navigate("/onboarding/age");
    } catch (err) {
      console.error("Signup error:", err);
      setError("An error occurred during signup. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-duolingo-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-lg border-2 border-duolingo-lightGray p-8">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-duolingo-darkGray">Create an Account</h1>
            <p className="text-duolingo-gray mt-2">Start your mental health journey today</p>
          </div>
          
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-duolingo-darkGray">Username</Label>
              <Input
                id="username"
                type="text"
                placeholder="Choose a username"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("username")}
                autoComplete="username"
              />
              {errors.username && (
                <p className="text-duolingo-red text-sm">{errors.username.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email" className="text-duolingo-darkGray">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("email")}
                autoComplete="email"
              />
              {errors.email && (
                <p className="text-duolingo-red text-sm">{errors.email.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-duolingo-darkGray">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a password"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("password")}
                autoComplete="new-password"
              />
              {errors.password && (
                <p className="text-duolingo-red text-sm">{errors.password.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-duolingo-darkGray">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirm your password"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("confirmPassword")}
                autoComplete="new-password"
              />
              {errors.confirmPassword && (
                <p className="text-duolingo-red text-sm">{errors.confirmPassword.message}</p>
              )}
            </div>
            
            <div className="pt-2">
              <Button 
                type="submit" 
                className="btn-duolingo w-full py-3 text-lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Creating Account..." : "Sign Up"}
              </Button>
            </div>
            
            <div className="text-center mt-6">
              <p className="text-duolingo-gray">
                Already have an account?{" "}
                <Link to="/login" className="text-duolingo-blue hover:underline font-medium">
                  Log In
                </Link>
              </p>
            </div>
          </form>
          
          <div className="mt-6 text-center text-xs text-duolingo-gray border-t border-duolingo-lightGray pt-4">
            <p>By signing up, you agree to our Terms of Service and Privacy Policy.</p>
          </div>
        </div>
      </div>
    </div>
  );
}