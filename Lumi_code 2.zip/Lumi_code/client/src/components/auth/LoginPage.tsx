import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useMentalApp } from "@/lib/stores/useMentalApp";

// Login form validation schema
const formSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type FormData = z.infer<typeof formSchema>;

export default function LoginPage() {
  const navigate = useNavigate();
  const { completeOnboarding, setName, setAgeGroup } = useMentalApp();
  const [error, setError] = useState<string | null>(null);
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  const onSubmit = async (data: FormData) => {
    setError(null);
    
    try {
      // In a real app, this would make an API call to verify credentials
      console.log("Login attempt with:", data);
      
      // Mock successful login
      // In a real app, this would be replaced with actual auth logic
      if (data.username === "demo" && data.password === "password") {
        // Set user data (would come from the server in a real app)
        setName("Demo User");
        setAgeGroup("teen");
        completeOnboarding();
        
        // Redirect to dashboard
        navigate("/");
      } else {
        setError("Invalid username or password");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError("An error occurred during login. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-duolingo-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-lg border-2 border-duolingo-lightGray p-8">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-duolingo-darkGray">Welcome Back!</h1>
            <p className="text-duolingo-gray mt-2">Log in to your mental health journey</p>
          </div>
          
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-duolingo-darkGray">Username</Label>
              <Input
                id="username"
                type="text"
                placeholder="Enter your username"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("username")}
                autoComplete="username"
              />
              {errors.username && (
                <p className="text-duolingo-red text-sm">{errors.username.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-duolingo-darkGray">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                className="rounded-xl border-duolingo-lightGray h-12"
                {...register("password")}
                autoComplete="current-password"
              />
              {errors.password && (
                <p className="text-duolingo-red text-sm">{errors.password.message}</p>
              )}
            </div>
            
            <div className="text-right">
              <Link to="/forgot-password" className="text-duolingo-blue text-sm hover:underline">
                Forgot password?
              </Link>
            </div>
            
            <Button 
              type="submit" 
              className="btn-duolingo w-full py-3 text-lg"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Logging in..." : "Log In"}
            </Button>
            
            <div className="text-center mt-6">
              <p className="text-duolingo-gray">
                Don't have an account?{" "}
                <Link to="/signup" className="text-duolingo-blue hover:underline font-medium">
                  Sign Up
                </Link>
              </p>
            </div>
          </form>
          
          {/* Demo mode notice */}
          <div className="mt-6 text-center text-sm text-duolingo-gray border-t border-duolingo-lightGray pt-4">
            <p>Demo Credentials:</p>
            <p>Username: <span className="font-medium">demo</span></p>
            <p>Password: <span className="font-medium">password</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}