import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Home, Menu, TrendingUp, PenTool, Smile, Award, Settings, X } from "lucide-react";

export default function Header() {
  const mentalApp = useMentalApp();
  const profile = mentalApp.onboardingCompleted ? { name: mentalApp.name, ageGroup: mentalApp.ageGroup } : null;
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Detect scroll for hiding header
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      if (scrollPosition > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", icon: <Home className="h-5 w-5" />, path: "/" },
    { name: "Games", icon: <Brain className="h-5 w-5" />, path: "/" },
    { name: "Journal", icon: <PenTool className="h-5 w-5" />, path: "/journal" },
    { name: "Mood", icon: <Smile className="h-5 w-5" />, path: "/mood" },
    { name: "Progress", icon: <TrendingUp className="h-5 w-5" />, path: "/progress" },
    { name: "Achievements", icon: <Award className="h-5 w-5" />, path: "/achievements" },
  ];

  return (
    <>
      <motion.header 
        className="bg-white sticky top-0 z-10 shadow-sm"
        initial={{ y: 0 }} 
        animate={{ y: scrolled ? -100 : 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="max-w-screen-xl mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center gap-2">
              <span className="bg-duolingo-green rounded-full p-1.5">
                <Brain className="h-6 w-6 text-white" />
              </span>
              <span className="font-bold text-xl text-duolingo-darkGray">Lumi</span>
            </Link>

            {/* Mobile menu button */}
            <div className="block md:hidden">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-duolingo-darkGray"
                onClick={() => setIsMenuOpen(true)}
              >
                <Menu className="h-6 w-6" />
              </Button>
            </div>
            
            {/* Desktop navigation */}
            <div className="hidden md:flex items-center gap-3">
              {profile ? (
                <>
                  <nav className="flex items-center gap-2 mr-4">
                    {navItems.map((item) => (
                      <Button
                        key={item.name}
                        className="font-bold text-duolingo-darkGray hover:bg-gray-100 rounded-xl"
                        variant="ghost"
                        size="sm"
                        asChild
                      >
                        <Link 
                          to={item.path} 
                          className="flex items-center gap-1"
                        >
                          <span className="text-duolingo-green">{item.icon}</span>
                          {item.name}
                        </Link>
                      </Button>
                    ))}
                  </nav>
                  <Button 
                    className="bg-duolingo-green text-white rounded-full h-10 w-10 p-0 hover:bg-duolingo-green/90"
                    onClick={() => navigate("/settings")}
                  >
                    <Settings className="h-5 w-5" />
                  </Button>
                </>
              ) : (
                <Button className="btn-duolingo px-6 py-3">
                  <Link to="/">Get Started</Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </motion.header>

      {/* Custom Mobile Menu Overlay - Duolingo Style */}
      {isMenuOpen && (
        <motion.div 
          className="fixed inset-0 bg-white z-50 md:hidden overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
        >
          <motion.div
            className="absolute inset-0 flex flex-col h-full"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.25 }}
          >
            <div className="p-4 flex flex-col h-full">
              <div className="flex justify-between items-center mb-8 border-b pb-4">
                <div className="flex items-center gap-2">
                  <span className="bg-duolingo-green rounded-full p-1.5">
                    <Brain className="h-6 w-6 text-white" />
                  </span>
                  <span className="font-bold text-xl text-duolingo-darkGray">Lumi</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-duolingo-darkGray hover:bg-gray-100 rounded-full"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <X className="h-6 w-6" />
                </Button>
              </div>
              
              <div className="space-y-3">
                {navItems.map((item) => (
                  <Button
                    key={item.name}
                    variant="ghost"
                    className="w-full justify-start gap-4 text-lg py-4 rounded-xl text-duolingo-darkGray font-bold hover:bg-gray-100"
                    onClick={() => {
                      navigate(item.path);
                      setIsMenuOpen(false);
                    }}
                  >
                    <span className="text-duolingo-green bg-duolingo-lightGray p-2 rounded-lg">
                      {item.icon}
                    </span>
                    {item.name}
                  </Button>
                ))}
              </div>
              
              <div className="mt-auto pt-4">
                <Button 
                  className="btn-duolingo w-full py-4 text-lg"
                  onClick={() => {
                    navigate("/settings");
                    setIsMenuOpen(false);
                  }}
                >
                  <span className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Settings
                  </span>
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}
