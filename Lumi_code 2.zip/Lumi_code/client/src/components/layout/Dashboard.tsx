import { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import Header from "./Header";
import GameCard from "../common/GameCard";
import MoodSelector from "../mood/MoodSelector";
import ProgressChart from "../progress/ProgressChart";
import AchievementCard from "../progress/AchievementCard";
import DailyQuote from "../quotes/DailyQuote";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { getGames, getAchievements } from "@/lib/gameData";
import { Sparkles } from "lucide-react";

export default function Dashboard() {
  const { name, ageGroup, onboardingCompleted, userProgress } = useMentalApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState("games");
  
  // Determine active tab based on route
  useEffect(() => {
    if (location.pathname === "/progress") {
      setActiveTab("progress");
    } else if (location.pathname === "/achievements") {
      setActiveTab("achievements");
    } else {
      setActiveTab("games");
    }
  }, [location.pathname]);
  
  // Redirect to onboarding if not completed
  useEffect(() => {
    console.log("Dashboard mounted, onboarding status:", onboardingCompleted);
    if (!onboardingCompleted) {
      console.log("Redirecting to onboarding...");
      navigate("/onboarding/age");
    }
  }, [onboardingCompleted, navigate]);
  
  // Initialize completedGames as an empty array if not available
  const completedGames: string[] = [];
  
  useEffect(() => {
    // No background music implementation yet
    console.log("Dashboard component mounted");
    
    return () => {
      console.log("Dashboard component unmounted");
    };
  }, []);

  const games = getGames(ageGroup || "children");
  const achievements = getAchievements();
  const todaysMoodEntry = userProgress?.moodEntries?.[0];
  const hasCompletedMoodToday = false; // Temporarily disabled

  return (
    <div className="min-h-screen pb-8">
      <Header />
      
      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-start gap-6">
          {/* Welcome section */}
          <div className="w-full md:w-2/3 space-y-6">
            <div className="bg-primary p-6 rounded-2xl text-primary-foreground shadow-lg">
              <div>
                <h1 className="text-2xl font-bold">
                  Hi {name || 'Friend'}! 
                </h1>
                <p className="text-lg mt-2">Ready to boost your mental strength today?</p>
              </div>
              
              {!hasCompletedMoodToday && (
                <div className="mt-6 p-4 bg-primary-foreground/10 rounded-xl">
                  <p className="font-medium mb-3">How are you feeling today?</p>
                  <MoodSelector compact />
                </div>
              )}
            </div>
            
            <Tabs value={activeTab} onValueChange={(value) => {
              // Navigate to the appropriate route when tab changes
              if (value === "progress") {
                navigate("/progress");
              } else if (value === "achievements") {
                navigate("/achievements");
              } else {
                navigate("/");
              }
            }} className="w-full">
              <TabsList className="grid w-full grid-cols-3 p-1 bg-muted rounded-xl">
                <TabsTrigger 
                  value="games" 
                  className="data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm rounded-lg text-muted-foreground font-bold py-2"
                >
                  Games
                </TabsTrigger>
                <TabsTrigger 
                  value="progress" 
                  className="data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm rounded-lg text-muted-foreground font-bold py-2"
                >
                  Progress
                </TabsTrigger>
                <TabsTrigger 
                  value="achievements" 
                  className="data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm rounded-lg text-muted-foreground font-bold py-2"
                >
                  Achievements
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="games" className="mt-6 space-y-5">
                <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                  <Sparkles className="text-secondary" size={22} />
                  Mental Strength Games
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {games.map((game) => (
                    <GameCard 
                      key={game.id} 
                      game={game} 
                      completed={completedGames.includes(game.id)}
                    />
                  ))}
                </div>
                
                <div className="mt-6">
                  <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                    <Sparkles className="text-accent" size={22} />
                    Daily Activities
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                    <Link to="/journal" className="block">
                      <div className="border-2 border-border rounded-xl p-5 hover:bg-accent/10 transition-all shadow-sm hover:shadow bg-card">
                        <h3 className="font-bold text-lg text-primary">Journal Entry</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          Reflect on your thoughts and feelings
                        </p>
                      </div>
                    </Link>
                    <Link to="/mood" className="block">
                      <div className="border-2 border-border rounded-xl p-5 hover:bg-accent/10 transition-all shadow-sm hover:shadow bg-card">
                        <h3 className="font-bold text-lg text-secondary">Mood Tracker</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          Track how your mood changes over time
                        </p>
                      </div>
                    </Link>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="progress" className="mt-6">
                <h2 className="text-xl font-bold text-foreground flex items-center gap-2 mb-5">
                  <Sparkles className="text-primary" size={22} />
                  Your Progress
                </h2>
                <ProgressChart />
              </TabsContent>
              
              <TabsContent value="achievements" className="mt-6">
                <h2 className="text-xl font-bold text-foreground flex items-center gap-2 mb-5">
                  <Sparkles className="text-accent" size={22} />
                  Your Achievements
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {achievements.map((achievement) => (
                    <AchievementCard
                      key={achievement.id}
                      achievement={achievement}
                      unlocked={userProgress?.achievements?.includes(achievement.id) || false}
                    />
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Side panel */}
          <div className="w-full md:w-1/3 space-y-6">
            {/* Daily Quote */}
            <DailyQuote />
            
            <div className="bg-card p-5 rounded-2xl shadow-md border-2 border-border">
              <h2 className="font-bold text-lg text-foreground">Today's Tip</h2>
              <p className="mt-2 text-foreground">
                Taking just 5 minutes to practice deep breathing can significantly reduce stress and improve focus.
              </p>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 w-full mt-4 py-3 rounded-xl" asChild>
                <Link to="/games/breathing">Try Breathing Exercise</Link>
              </Button>
            </div>
            
            {hasCompletedMoodToday && (
              <div className="bg-card p-5 rounded-2xl shadow-md border-2 border-border">
                <h2 className="font-bold text-lg text-foreground">Today's Mood</h2>
                <div className="flex items-center gap-2 mt-3">
                  <div className="text-3xl">
                    {todaysMoodEntry?.emoji}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{todaysMoodEntry?.mood}</p>
                    <p className="text-sm text-muted-foreground">
                      {todaysMoodEntry?.note || "No note added"}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="bg-card p-5 rounded-2xl shadow-md border-2 border-border">
              <h2 className="font-bold text-lg text-foreground">Progress Streak</h2>
              <div className="mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-foreground">Current streak</span>
                  <span className="font-bold text-xl text-primary">{userProgress?.streak || 0} days</span>
                </div>
                <div className="w-full bg-muted h-3 rounded-full mt-3">
                  <div 
                    className="bg-primary h-3 rounded-full" 
                    style={{ 
                      width: `${Math.min(((userProgress?.streak || 0) / 7) * 100, 100)}%` 
                    }}
                  ></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {7 - (userProgress?.streak || 0) % 7} more days until next achievement
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
