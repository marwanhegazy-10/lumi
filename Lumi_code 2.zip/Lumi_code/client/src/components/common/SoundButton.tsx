import React from "react";
import { useAudio } from "@/lib/stores/useAudio";
import { Button } from "@/components/ui/button";
import { ButtonProps } from "@/components/ui/button";

interface SoundButtonProps extends ButtonProps {
  soundType?: "click" | "success" | "error" | "complete" | "notification";
}

// This button component adds sound effects when clicked
const SoundButton = React.forwardRef<HTMLButtonElement, SoundButtonProps>(
  ({ soundType = "click", onClick, ...props }, ref) => {
    const { playClick, playSuccess, playError, playComplete, playNotification } = useAudio();

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      // Play the appropriate sound
      switch (soundType) {
        case "success":
          playSuccess();
          break;
        case "error":
          playError();
          break;
        case "complete":
          playComplete();
          break;
        case "notification":
          playNotification();
          break;
        case "click":
        default:
          playClick();
          break;
      }

      // Call the original onClick handler if it exists
      if (onClick) {
        onClick(event);
      }
    };

    return <Button ref={ref} onClick={handleClick} {...props} />;
  }
);

SoundButton.displayName = "SoundButton";

export default SoundButton;