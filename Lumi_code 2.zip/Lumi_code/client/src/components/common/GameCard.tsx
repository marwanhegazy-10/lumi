import { Link } from "react-router-dom";
import { Game } from "@/lib/types";
import { Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface GameCardProps {
  game: Game;
  completed?: boolean;
}

export default function GameCard({ game, completed = false }: GameCardProps) {
  // Map categories to Duolingo colors
  const getCategoryColor = (category: string) => {
    switch(category) {
      case "focus":
        return "bg-duolingo-blue text-white";
      case "emotional":
        return "bg-duolingo-purple text-white";
      case "calm":
        return "bg-duolingo-green text-white";
      case "cognitive":
        return "bg-duolingo-orange text-white";
      default:
        return "bg-duolingo-blue text-white";
    }
  };
  
  // Get border color for the card
  const getBorderColor = (category: string) => {
    switch(category) {
      case "focus":
        return "border-duolingo-blue";
      case "emotional":
        return "border-duolingo-purple";
      case "calm":
        return "border-duolingo-green";
      case "cognitive":
        return "border-duolingo-orange";
      default:
        return "border-duolingo-blue";
    }
  };
  
  return (
    <div className={`bg-white rounded-2xl overflow-hidden transition-all hover:shadow-md border-2 ${getBorderColor(game.category)}`}>
      <div className="p-5">
        <div className="flex flex-col h-full">
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-center gap-2">
              <div 
                className={`rounded-lg p-2 ${getCategoryColor(game.category)}`}
              >
                <game.icon className="h-5 w-5" />
              </div>
              <span className="text-sm font-bold capitalize text-duolingo-darkGray">
                {game.category}
              </span>
            </div>
            
            {completed && (
              <div className="bg-duolingo-green/10 text-duolingo-green rounded-full p-1.5">
                <CheckCircle className="h-5 w-5" />
              </div>
            )}
          </div>
          
          <h3 className="font-bold text-lg mb-2 text-duolingo-darkGray">{game.title}</h3>
          <p className="text-sm text-gray-600 line-clamp-2 mb-4">
            {game.description}
          </p>
          
          <div className="mt-auto flex items-center text-xs text-gray-500 gap-1 mb-4">
            <Clock className="h-4 w-4" />
            <span className="text-sm">{game.duration}</span>
          </div>
          
          <Button className="btn-duolingo w-full py-3 text-base" asChild>
            <Link to={game.path}>
              {completed ? "Play Again" : "Start Game"}
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
