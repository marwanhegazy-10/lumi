import { useState } from "react";
import { useJournal } from "@/lib/hooks/useJournal";
import { JournalEntry as JournalEntryType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Trash2, Edit, Calendar, PenSquare } from "lucide-react";

interface JournalEntryProps {
  entry: JournalEntryType;
}

export default function JournalEntry({ entry }: JournalEntryProps) {
  const { deleteEntry } = useJournal();
  const [isExpanded, setIsExpanded] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  const handleDelete = () => {
    deleteEntry(entry.id);
    setShowDeleteDialog(false);
  };

  return (
    <div className="border rounded-lg p-4 hover:bg-muted/10 transition-colors">
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{formatDate(entry.date)}</span>
        </div>
        
        <div className="flex gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={() => setShowDeleteDialog(true)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="mb-3">
        <div className="flex items-center gap-1 text-sm font-medium text-primary mb-1">
          <PenSquare className="h-4 w-4" />
          <span>Prompt</span>
        </div>
        <p className="text-sm">{entry.prompt}</p>
      </div>
      
      <div className={`prose prose-sm max-w-none ${!isExpanded && 'line-clamp-3'}`}>
        {entry.content.split("\n").map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
      
      {entry.content.length > 150 && (
        <Button 
          variant="link" 
          size="sm" 
          className="mt-1 h-auto p-0"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? "Show less" : "Read more"}
        </Button>
      )}
      
      {/* Delete confirmation dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this journal entry. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
