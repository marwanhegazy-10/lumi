import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useJournal } from "@/lib/hooks/useJournal";
import Header from "../layout/Header";
import JournalEntry from "./JournalEntry";
import { getRandomPrompt } from "@/lib/prompts";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  Save,
  BookOpen, 
  Sparkles
} from "lucide-react";

export default function JournalPrompt() {
  const { ageGroup } = useMentalApp();
  const { addEntry, entries, currentPrompt, setCurrentPrompt } = useJournal();
  const [content, setContent] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const navigate = useNavigate();
  
  // Get a random prompt if we don't have one
  useEffect(() => {
    if (!currentPrompt) {
      const prompt = getRandomPrompt(ageGroup);
      setCurrentPrompt(prompt);
    }
  }, [currentPrompt, setCurrentPrompt, ageGroup]);
  
  // Get new random prompt
  const getNewPrompt = () => {
    const prompt = getRandomPrompt(ageGroup);
    setCurrentPrompt(prompt);
  };
  
  // Save journal entry
  const saveEntry = async () => {
    if (!content.trim()) return;
    
    setIsSubmitting(true);
    
    try {
      await addEntry({
        id: Date.now().toString(),
        date: new Date().toISOString(),
        prompt: currentPrompt?.text || "Free writing",
        content,
        mood: "unspecified"
      });
      
      setSuccessMessage("Journal entry saved successfully!");
      setContent("");
      getNewPrompt();
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage("");
      }, 3000);
    } catch (error) {
      console.error("Error saving journal entry:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-3xl mx-auto">
          <Tabs defaultValue="write">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="write">
                <Sparkles className="h-4 w-4 mr-2" />
                Write
              </TabsTrigger>
              <TabsTrigger value="history">
                <BookOpen className="h-4 w-4 mr-2" />
                Your Journal
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="write">
              <div className="bg-card p-6 rounded-xl shadow mt-4">
                <h1 className="text-2xl font-bold mb-6">Journal</h1>
                
                {currentPrompt && (
                  <div className="mb-6">
                    <div className="bg-primary/10 p-4 rounded-lg mb-4">
                      <h2 className="text-lg font-semibold mb-2">Today's Prompt:</h2>
                      <p>{currentPrompt.text}</p>
                      {currentPrompt.helpText && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {currentPrompt.helpText}
                        </p>
                      )}
                    </div>
                    
                    <Button 
                      variant="outline" 
                      onClick={getNewPrompt}
                      className="w-full sm:w-auto"
                    >
                      Get Different Prompt
                    </Button>
                  </div>
                )}
                
                <div className="space-y-4">
                  <Textarea
                    placeholder="Start writing here..."
                    className="min-h-[200px]"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                  />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      {successMessage && (
                        <p className="text-green-600 text-sm">{successMessage}</p>
                      )}
                    </div>
                    <Button 
                      onClick={saveEntry}
                      disabled={!content.trim() || isSubmitting}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Entry
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="bg-card p-6 rounded-xl shadow mt-6">
                <h2 className="text-xl font-semibold mb-3">Benefits of Journaling</h2>
                <ul className="space-y-2 list-disc pl-5">
                  <li>Helps process and understand your emotions</li>
                  <li>Reduces stress and anxiety</li>
                  <li>Improves self-awareness and personal growth</li>
                  <li>Strengthens memory and problem-solving skills</li>
                  <li>Creates a record of your progress and accomplishments</li>
                </ul>
                
                <div className="mt-4 p-3 bg-amber-50 border border-amber-100 rounded-lg">
                  <p className="text-sm">
                    <strong>Tip:</strong> Try to journal regularly, even if just for a few minutes. 
                    There's no right or wrong way to journal - write whatever comes to mind!
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="history">
              <div className="bg-card p-6 rounded-xl shadow mt-4">
                <h1 className="text-2xl font-bold mb-6">Your Journal Entries</h1>
                
                {entries.length === 0 ? (
                  <div className="text-center py-8 bg-muted/30 rounded-lg">
                    <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                    <p>You haven't created any journal entries yet.</p>
                    <Button 
                      variant="link" 
                      onClick={() => {
                        const tab = document.querySelector('[data-state="inactive"][value="write"]');
                        if (tab) {
                          (tab as HTMLElement).click();
                        }
                      }}
                    >
                      Start writing
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {entries.slice().reverse().map((entry) => (
                      <JournalEntry key={entry.id} entry={entry} />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
