import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import { format } from "date-fns";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Heart, Calendar, Plus, Save, Trash2, Star, SunMoon, Coffee } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Type definitions
interface GratitudeEntry {
  id: string;
  date: string;
  items: {
    id: string;
    text: string;
    category: GratitudeCategory;
  }[];
  reflection: string;
}

type GratitudeCategory = "people" | "experiences" | "things" | "personal" | "nature";

// Helper function to get category icon
const getCategoryIcon = (category: GratitudeCategory) => {
  switch (category) {
    case "people":
      return <Heart className="h-4 w-4" />;
    case "experiences":
      return <Star className="h-4 w-4" />;
    case "things":
      return <Coffee className="h-4 w-4" />;
    case "personal":
      return <SunMoon className="h-4 w-4" />;
    case "nature":
      return <Calendar className="h-4 w-4" />;
    default:
      return <Heart className="h-4 w-4" />;
  }
};

// Helper function to get category color
const getCategoryColor = (category: GratitudeCategory) => {
  switch (category) {
    case "people":
      return "bg-pink-100 text-pink-800 border-pink-200";
    case "experiences":
      return "bg-purple-100 text-purple-800 border-purple-200";
    case "things":
      return "bg-blue-100 text-blue-800 border-blue-200";
    case "personal":
      return "bg-amber-100 text-amber-800 border-amber-200";
    case "nature":
      return "bg-green-100 text-green-800 border-green-200";
    default:
      return "bg-gray-100 text-gray-800 border-gray-200";
  }
};

// Sample gratitude prompts by category
const CATEGORY_PROMPTS: Record<GratitudeCategory, string[]> = {
  people: [
    "Who made you smile today?",
    "Who taught you something valuable recently?",
    "Who do you appreciate having in your life?",
    "Who helped you when you needed it?",
    "Who makes you feel safe?",
  ],
  experiences: [
    "What moment brought you joy today?",
    "What experience are you looking forward to?",
    "What memory makes you smile when you think about it?",
    "What did you enjoy doing recently?",
    "What experience helped you grow?",
  ],
  things: [
    "What simple pleasure are you thankful for?",
    "What tool or item made your day easier?",
    "What's something you own that brings you comfort?",
    "What food did you enjoy today?",
    "What technology are you grateful to have?",
  ],
  personal: [
    "What personal quality or strength are you grateful for?",
    "What health aspect are you thankful for?",
    "What did your body allow you to do today?",
    "What skill or knowledge are you grateful to have?",
    "What personal achievement are you proud of?",
  ],
  nature: [
    "What in nature did you appreciate today?",
    "What weather condition did you enjoy?",
    "What animal or plant brought you joy?",
    "What natural beauty caught your attention?",
    "What element of nature made you feel peaceful?",
  ],
};

export default function GratitudeJournal() {
  const [activeTab, setActiveTab] = useState<"write" | "history">("write");
  const [gratitudeEntries, setGratitudeEntries] = useState<GratitudeEntry[]>([]);
  const [currentEntry, setCurrentEntry] = useState<GratitudeEntry>({
    id: uuidv4(),
    date: new Date().toISOString(),
    items: [
      { id: uuidv4(), text: "", category: "people" },
      { id: uuidv4(), text: "", category: "experiences" },
      { id: uuidv4(), text: "", category: "personal" },
    ],
    reflection: "",
  });
  const [editingEntry, setEditingEntry] = useState<string | null>(null);
  const [prompts, setPrompts] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const navigate = useNavigate();
  const { addJournalEntry } = useMentalApp();
  const { playSuccess } = useAudio();
  
  // Set random prompts for each gratitude item
  useEffect(() => {
    const newPrompts: Record<string, string> = {};
    
    currentEntry.items.forEach(item => {
      const categoryPrompts = CATEGORY_PROMPTS[item.category];
      const randomPrompt = categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)];
      newPrompts[item.id] = randomPrompt;
    });
    
    setPrompts(newPrompts);
  }, [currentEntry.items]);
  
  // Load entries from local storage
  useEffect(() => {
    const savedEntries = localStorage.getItem("gratitude-entries");
    if (savedEntries) {
      setGratitudeEntries(JSON.parse(savedEntries));
    }
  }, []);
  
  // Helper function to update gratitude items
  const updateGratitudeItem = (itemId: string, text: string) => {
    setCurrentEntry(prev => ({
      ...prev,
      items: prev.items.map(item => 
        item.id === itemId ? { ...item, text } : item
      ),
    }));
  };
  
  // Helper function to update an item's category
  const updateItemCategory = (itemId: string, category: GratitudeCategory) => {
    setCurrentEntry(prev => ({
      ...prev,
      items: prev.items.map(item => 
        item.id === itemId ? { ...item, category } : item
      ),
    }));
    
    // Update the prompt for the new category
    const categoryPrompts = CATEGORY_PROMPTS[category];
    const randomPrompt = categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)];
    setPrompts(prev => ({
      ...prev,
      [itemId]: randomPrompt
    }));
  };
  
  // Helper function to add a new gratitude item
  const addGratitudeItem = () => {
    const newItemId = uuidv4();
    const categories: GratitudeCategory[] = ["people", "experiences", "things", "personal", "nature"];
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    
    setCurrentEntry(prev => ({
      ...prev,
      items: [
        ...prev.items, 
        { id: newItemId, text: "", category: randomCategory }
      ],
    }));
    
    // Set a prompt for the new item
    const categoryPrompts = CATEGORY_PROMPTS[randomCategory];
    const randomPrompt = categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)];
    setPrompts(prev => ({
      ...prev,
      [newItemId]: randomPrompt
    }));
  };
  
  // Helper function to remove a gratitude item
  const removeGratitudeItem = (itemId: string) => {
    setCurrentEntry(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== itemId),
    }));
  };
  
  // Handle form submission
  const handleSubmit = async () => {
    if (isSubmitting) return;
    
    // Validate the entry - require at least one filled gratitude item
    const filledItems = currentEntry.items.filter(item => item.text.trim() !== "");
    if (filledItems.length === 0) {
      alert("Please add at least one gratitude item.");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Create a journal entry from the gratitude
      const gratitudeTitle = `Gratitude: ${
        filledItems.length > 0 
          ? filledItems[0].text.slice(0, 30) + (filledItems[0].text.length > 30 ? "..." : "")
          : "My gratitude list"
      }`;
      
      // Create content from all items
      const content = `
        ${currentEntry.items
          .filter(item => item.text.trim() !== "")
          .map(item => `• ${item.text} (${item.category})`)
          .join("\n")}
        
        ${currentEntry.reflection ? `\nReflection: ${currentEntry.reflection}` : ""}
      `;
      
      // Add to journal entries
      await addJournalEntry({
        id: currentEntry.id,
        date: currentEntry.date,
        prompt: "What are you grateful for today?",
        content: content.trim(),
        mood: "grateful"
      });
      
      // Save to local storage for our specialized gratitude format
      const updatedEntries = [
        {...currentEntry, date: new Date().toISOString()}, 
        ...gratitudeEntries
      ];
      setGratitudeEntries(updatedEntries);
      localStorage.setItem("gratitude-entries", JSON.stringify(updatedEntries));
      
      // Play success sound
      playSuccess();
      
      // Reset form
      setCurrentEntry({
        id: uuidv4(),
        date: new Date().toISOString(),
        items: [
          { id: uuidv4(), text: "", category: "people" },
          { id: uuidv4(), text: "", category: "experiences" },
          { id: uuidv4(), text: "", category: "personal" },
        ],
        reflection: "",
      });
      
      // Switch to history tab
      setActiveTab("history");
    } catch (error) {
      console.error("Error saving gratitude entry:", error);
      alert("There was an error saving your entry. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Delete an entry
  const deleteEntry = (entryId: string) => {
    if (confirm("Are you sure you want to delete this gratitude entry?")) {
      const updatedEntries = gratitudeEntries.filter(entry => entry.id !== entryId);
      setGratitudeEntries(updatedEntries);
      localStorage.setItem("gratitude-entries", JSON.stringify(updatedEntries));
    }
  };
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Heart className="h-5 w-5 text-rose-500" />
              Gratitude Journal
            </h1>
            
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="write">Write Today's Entry</TabsTrigger>
                <TabsTrigger value="history">View Entries</TabsTrigger>
              </TabsList>
              
              <TabsContent value="write" className="space-y-6">
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800">
                  <p>Research shows that practicing gratitude regularly can:</p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Increase happiness and positive mood</li>
                    <li>Reduce anxiety and depression</li>
                    <li>Strengthen resilience</li>
                    <li>Improve sleep</li>
                    <li>Build stronger relationships</li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <h2 className="font-medium text-lg">I am grateful for...</h2>
                  
                  <AnimatePresence>
                    {currentEntry.items.map((item, index) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-1"
                      >
                        <div className="flex gap-2">
                          <div className="flex-1">
                            <Label htmlFor={`item-${item.id}`} className="text-sm text-muted-foreground">
                              {prompts[item.id] || `What are you grateful for? (#${index + 1})`}
                            </Label>
                            <div className="flex gap-2 mt-1">
                              <Input
                                id={`item-${item.id}`}
                                value={item.text}
                                onChange={(e) => updateGratitudeItem(item.id, e.target.value)}
                                placeholder="I am grateful for..."
                                className="flex-1"
                              />
                              
                              <div className="flex">
                                <select
                                  value={item.category}
                                  onChange={(e) => updateItemCategory(item.id, e.target.value as GratitudeCategory)}
                                  className="border rounded px-2 py-1 text-sm bg-background"
                                >
                                  <option value="people">People</option>
                                  <option value="experiences">Experiences</option>
                                  <option value="things">Things</option>
                                  <option value="personal">Personal</option>
                                  <option value="nature">Nature</option>
                                </select>
                                
                                {currentEntry.items.length > 1 && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-9 w-9 text-muted-foreground hover:text-destructive"
                                    onClick={() => removeGratitudeItem(item.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={addGratitudeItem}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Another
                  </Button>
                  
                  <div className="pt-4">
                    <Label htmlFor="reflection" className="text-sm">
                      Reflection (optional)
                    </Label>
                    <Textarea
                      id="reflection"
                      value={currentEntry.reflection}
                      onChange={(e) => setCurrentEntry(prev => ({ ...prev, reflection: e.target.value }))}
                      placeholder="How does practicing gratitude make you feel?"
                      className="mt-1"
                      rows={3}
                    />
                  </div>
                  
                  <Button
                    className="w-full"
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Gratitude Entry
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="history">
                {gratitudeEntries.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">You haven't created any gratitude entries yet.</p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() => setActiveTab("write")}
                    >
                      Write Your First Entry
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {gratitudeEntries.map((entry) => (
                      <Card key={entry.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="p-4 border-b bg-muted/30">
                            <div className="flex justify-between items-center">
                              <div className="font-medium">
                                {format(new Date(entry.date), "MMMM d, yyyy")}
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                onClick={() => deleteEntry(entry.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          
                          <div className="p-4 space-y-3">
                            {entry.items.filter(item => item.text.trim() !== "").map((item) => (
                              <div 
                                key={item.id} 
                                className={`rounded-lg border p-3 flex items-start gap-2 ${getCategoryColor(item.category)}`}
                              >
                                <div className="mt-0.5">
                                  {getCategoryIcon(item.category)}
                                </div>
                                <div>
                                  <p>{item.text}</p>
                                  <p className="text-xs mt-1 opacity-70">{item.category}</p>
                                </div>
                              </div>
                            ))}
                            
                            {entry.reflection && (
                              <div className="border rounded-lg p-3 mt-3">
                                <p className="text-sm font-medium mb-1">Reflection:</p>
                                <p className="text-sm text-muted-foreground">{entry.reflection}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}