import { useEffect, useState } from 'react';
import { getDailyQuote, Quote } from '@/lib/quotes';
import { motion } from 'framer-motion';
import { Quote as QuoteIcon, Copy, CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface DailyQuoteProps {
  className?: string;
}

export default function DailyQuote({ className }: DailyQuoteProps) {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Get the daily quote when component mounts
    setQuote(getDailyQuote());
  }, []);

  const copyToClipboard = () => {
    if (!quote) return;
    
    const textToCopy = `"${quote.text}" - ${quote.author}`;
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      
      // Reset copied state after 2 seconds
      setTimeout(() => {
        setCopied(false);
      }, 2000);
    });
  };

  if (!quote) return null;

  return (
    <motion.div 
      className={cn(
        "relative p-6 bg-card border border-border rounded-2xl shadow-sm overflow-hidden",
        className
      )}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="absolute top-4 right-4 text-muted-foreground opacity-10">
        <QuoteIcon size={40} />
      </div>
      
      <div className="mb-4">
        <span className="text-sm font-medium text-primary">Daily Inspiration</span>
      </div>
      
      <blockquote className="mb-4 relative">
        <p className="text-lg font-medium text-foreground">"{quote.text}"</p>
        <footer className="mt-2 text-sm text-muted-foreground">— {quote.author}</footer>
      </blockquote>
      
      <Button 
        variant="ghost" 
        size="sm" 
        className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
        onClick={copyToClipboard}
      >
        {copied ? (
          <>
            <CheckCheck size={14} />
            <span>Copied!</span>
          </>
        ) : (
          <>
            <Copy size={14} />
            <span>Copy quote</span>
          </>
        )}
      </Button>
    </motion.div>
  );
}