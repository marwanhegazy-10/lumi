import { useState, useEffect } from "react";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import { AnimatePresence, motion } from "framer-motion";
import { Flame, X, Award, Star, Calendar } from "lucide-react";
import Confetti from "react-confetti";
import { useWindowSize } from "react-use";

export default function StreakNotification() {
  const [visible, setVisible] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const { width, height } = useWindowSize();
  
  const { getStreakInfo } = useMentalApp();
  const { playSuccess } = useAudio();
  
  const checkStreak = () => {
    const { current, isNewStreak } = getStreakInfo();
    
    // Show notification for streaks of 2 or more days, and only on new streak days
    if (current >= 2 && isNewStreak) {
      setVisible(true);
      setShowConfetti(true);
      playSuccess();
      
      // Hide confetti after 4 seconds
      setTimeout(() => {
        setShowConfetti(false);
      }, 4000);
      
      // Auto-hide notification after 8 seconds
      setTimeout(() => {
        setVisible(false);
      }, 8000);
    }
  };
  
  // Check streak when component mounts
  useEffect(() => {
    // Small delay to ensure the app has loaded properly
    const timer = setTimeout(() => {
      checkStreak();
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  const getStreakMessage = (streak: number): string => {
    if (streak >= 30) return "Amazing! A whole month of dedication!";
    if (streak >= 21) return "Incredible! You're building lasting habits!";
    if (streak >= 14) return "Two weeks! Your commitment is impressive!";
    if (streak >= 7) return "A full week! You're creating healthy patterns!";
    if (streak >= 5) return "Five days strong! Keep the momentum going!";
    if (streak === 3) return "Three days in a row! Building consistency!";
    return "Two days in a row! You're on your way!";
  };
  
  const { current: streakCount } = getStreakInfo();
  
  return (
    <>
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50">
          <Confetti
            width={width}
            height={height}
            numberOfPieces={150}
            gravity={0.2}
            recycle={false}
          />
        </div>
      )}
      
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed top-4 inset-x-0 mx-auto z-40 w-full max-w-md px-4"
          >
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-lg shadow-lg overflow-hidden">
              <div className="relative p-4">
                <button 
                  onClick={() => setVisible(false)}
                  className="absolute top-2 right-2 text-white/80 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
                
                <div className="flex items-center gap-4">
                  <div className="flex-shrink-0 bg-white/20 rounded-full p-3">
                    <Flame className="h-8 w-8 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-white text-lg font-bold">
                      {streakCount} Day Streak!
                    </h3>
                    <p className="text-white/90">
                      {getStreakMessage(streakCount)}
                    </p>
                  </div>
                </div>
                
                <div className="mt-3 pt-3 border-t border-white/20 flex justify-between items-center">
                  <div className="flex items-center gap-1 text-white/80 text-sm">
                    <Calendar className="h-4 w-4" />
                    <span>Keep going for more rewards!</span>
                  </div>
                  
                  <div className="flex gap-1">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Star 
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.min(Math.floor(streakCount / 7), 3)
                            ? "text-yellow-300 fill-yellow-300"
                            : "text-white/40"
                        }`} 
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}