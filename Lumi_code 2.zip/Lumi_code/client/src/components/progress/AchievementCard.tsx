import { Achievement } from "@/lib/types";
import { motion } from "framer-motion";
import { Trophy, Lock } from "lucide-react";

interface AchievementCardProps {
  achievement: Achievement;
  unlocked: boolean;
}

export default function AchievementCard({ achievement, unlocked }: AchievementCardProps) {
  // Map achievement categories to Duolingo colors
  const getCategoryColor = (category: string) => {
    switch(category) {
      case "streak":
        return "bg-duolingo-orange text-white";
      case "games":
        return "bg-duolingo-green text-white";
      case "journal":
        return "bg-duolingo-purple text-white";
      case "mood":
        return "bg-duolingo-blue text-white";
      default:
        return "bg-duolingo-yellow text-duolingo-brown";
    }
  };
  
  const getBorderColor = (category: string) => {
    switch(category) {
      case "streak":
        return "border-duolingo-orange";
      case "games":
        return "border-duolingo-green";
      case "journal":
        return "border-duolingo-purple";
      case "mood":
        return "border-duolingo-blue";
      default:
        return "border-duolingo-yellow";
    }
  };
  
  return (
    <div 
      className={`border-2 rounded-2xl p-5 shadow-sm ${
        unlocked 
          ? `bg-white ${getBorderColor(achievement.category)}` 
          : "bg-duolingo-lightGray border-gray-300"
      }`}
    >
      <div className="flex items-start gap-4">
        <div 
          className={`rounded-lg p-3 ${
            unlocked 
              ? getCategoryColor(achievement.category)
              : "bg-gray-300 text-white"
          }`}
        >
          {unlocked ? (
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: [0, 15, -15, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 3 }}
            >
              <Trophy className="h-6 w-6" />
            </motion.div>
          ) : (
            <Lock className="h-6 w-6" />
          )}
        </div>
        
        <div>
          <h3 className={`font-bold ${!unlocked ? "text-gray-500" : "text-duolingo-darkGray"}`}>
            {achievement.name}
          </h3>
          <p className={`text-sm mt-1 ${!unlocked ? "text-gray-500" : "text-duolingo-darkGray"}`}>
            {achievement.description}
          </p>
          
          {unlocked && achievement.reward && (
            <div className="mt-3 text-sm font-bold bg-duolingo-yellow/20 text-duolingo-brown px-3 py-1.5 rounded-lg inline-block">
              {achievement.reward}
            </div>
          )}
          
          {!unlocked && achievement.criteria && (
            <p className="text-xs text-gray-500 mt-2">
              {achievement.criteria}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
