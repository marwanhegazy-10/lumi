import { useNavigate } from "react-router-dom";
import Header from "../layout/Header";
import ProgressChart from "./ProgressChart";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function ProgressPage() {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen pb-8">
      <Header />
      
      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-3xl mx-auto">
          <h1 className="text-2xl font-bold text-duolingo-darkGray mb-6">Your Progress</h1>
          <ProgressChart />
        </div>
      </main>
    </div>
  );
}