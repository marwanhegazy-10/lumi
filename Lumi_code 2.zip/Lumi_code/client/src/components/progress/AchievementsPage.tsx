import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import Header from "../layout/Header";
import AchievementCard from "./AchievementCard";
import { getAchievements } from "@/lib/gameData";
import { Sparkles, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AchievementsPage() {
  const { userProgress } = useMentalApp();
  const navigate = useNavigate();
  
  useEffect(() => {
    // Component mounted effect
    console.log("Achievements page mounted");
    return () => {
      console.log("Achievements page unmounted");
    };
  }, []);

  const achievements = getAchievements();

  return (
    <div className="min-h-screen pb-8">
      <Header />
      
      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="flex flex-col gap-6 max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="h-6 w-6 text-duolingo-yellow" />
            <h1 className="text-2xl font-bold text-duolingo-darkGray">Your Achievements</h1>
          </div>
          
          <div className="bg-white p-5 rounded-2xl border-2 border-duolingo-lightGray shadow-sm">
            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center bg-duolingo-lightGray/30 p-4 rounded-xl">
                <div>
                  <h2 className="font-bold text-lg text-duolingo-darkGray">Total Achievements</h2>
                  <p className="text-duolingo-darkGray">Track your personal growth journey</p>
                </div>
                <div className="text-3xl font-bold text-duolingo-green">
                  {userProgress?.achievements?.length || 0}/{achievements.length}
                </div>
              </div>
              
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-5">
                {achievements.map((achievement) => (
                  <AchievementCard
                    key={achievement.id}
                    achievement={achievement}
                    unlocked={userProgress?.achievements?.includes(achievement.id) || false}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}