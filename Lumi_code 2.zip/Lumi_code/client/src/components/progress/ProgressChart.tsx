import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useMoodTracking } from "@/lib/hooks/useMoodTracking";
import { useJournal } from "@/lib/hooks/useJournal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function ProgressChart() {
  const { userProgress } = useMentalApp();
  const { moodEntries } = useMoodTracking();
  const { entries } = useJournal();
  
  // Since completedGames is not defined in useMentalApp store, provide a default empty array
  const completedGames: string[] = [];
  
  // Prepare activity data for the past 14 days
  const last14Days = Array.from({ length: 14 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date;
  }).reverse();
  
  const formatChartDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };
  
  // Count activities by date
  const activityByDate = last14Days.map(date => {
    const dateString = date.toDateString();
    
    // Count journal entries for this date (with null safety)
    const journalCount = entries && entries.length ? entries.filter(entry => 
      entry && entry.date && new Date(entry.date).toDateString() === dateString
    ).length : 0;
    
    // Count mood entries for this date (with null safety)
    const moodCount = moodEntries && moodEntries.length ? moodEntries.filter(entry => 
      entry && entry.date && new Date(entry.date).toDateString() === dateString
    ).length : 0;
    
    // Count completed games for this date (would need timestamps on completed games)
    // This is a simplified version since we don't have timestamps in the current model
    const gameCount = 0; // Placeholder for actual game completion data
    
    return {
      date: formatChartDate(date),
      total: journalCount + moodCount + gameCount,
      journal: journalCount,
      mood: moodCount,
      games: gameCount
    };
  });
  
  // Prepare mood data (with null safety)
  const moodData = last14Days.map(date => {
    const dateString = date.toDateString();
    
    // Find mood entry for this date
    const moodEntry = moodEntries && moodEntries.length ? moodEntries.find(entry => 
      entry && entry.date && new Date(entry.date).toDateString() === dateString
    ) : undefined;
    
    return {
      date: formatChartDate(date),
      value: moodEntry ? moodEntry.value : null
    };
  });
  
  // Activity chart data
  const activityChartData = {
    labels: activityByDate.map(item => item.date),
    datasets: [
      {
        label: 'Journal Entries',
        data: activityByDate.map(item => item.journal),
        backgroundColor: 'rgba(124, 58, 237, 0.6)',
        stack: 'Stack 0',
      },
      {
        label: 'Mood Check-ins',
        data: activityByDate.map(item => item.mood),
        backgroundColor: 'rgba(59, 130, 246, 0.6)',
        stack: 'Stack 0',
      },
      {
        label: 'Games Completed',
        data: activityByDate.map(item => item.games),
        backgroundColor: 'rgba(16, 185, 129, 0.6)',
        stack: 'Stack 0',
      }
    ],
  };
  
  const activityChartOptions: ChartOptions<'bar'> = {
    plugins: {
      title: {
        display: true,
        text: 'Daily Activities'
      },
      legend: {
        position: 'bottom',
      },
    },
    responsive: true,
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
        ticks: {
          precision: 0
        }
      },
    },
  };
  
  // Mood chart data
  const moodChartData = {
    labels: moodData.map(item => item.date),
    datasets: [
      {
        label: 'Mood Level',
        data: moodData.map(item => item.value),
        fill: false,
        borderColor: 'rgb(99, 102, 241)',
        tension: 0.3,
        pointBackgroundColor: 'rgb(99, 102, 241)',
        pointRadius: (ctx: any) => {
          const value = ctx.dataset.data[ctx.dataIndex];
          return value === null ? 0 : 4;
        },
      },
    ],
  };
  
  const moodChartOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Mood Trends'
      }
    },
    scales: {
      y: {
        min: 1,
        max: 5,
        ticks: {
          stepSize: 1,
          callback: function(value: any) {
            const moodLabels: {[key: number]: string} = {
              1: 'Very Low',
              2: 'Low',
              3: 'Neutral',
              4: 'Good',
              5: 'Excellent',
            };
            return moodLabels[value] || '';
          }
        }
      }
    },
  };
  
  // Calculate progress metrics
  const totalGamesAvailable = 4; // Update this as you add more games
  const gamesCompletionPercentage = Math.round((completedGames.length / totalGamesAvailable) * 100);
  
  const journalStreakDays = userProgress?.journalStreak || 0;
  const moodStreakDays = userProgress?.moodStreak || 0;
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Games Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {completedGames.length}/{totalGamesAvailable}
              <span className="text-sm font-normal text-muted-foreground ml-2">
                ({gamesCompletionPercentage}%)
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Journal Streak</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {journalStreakDays}
              <span className="text-sm font-normal text-muted-foreground ml-2">
                days
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Mood Check-in Streak</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {moodStreakDays}
              <span className="text-sm font-normal text-muted-foreground ml-2">
                days
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Activity Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <Bar data={activityChartData} options={activityChartOptions} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Mood Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <Line data={moodChartData} options={moodChartOptions} />
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Growth Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-3 bg-green-50 border border-green-100 rounded-lg">
              <h3 className="font-medium">Your strengths</h3>
              <p className="text-sm mt-1">
                Based on your activities, you're building skills in {completedGames.length > 0 
                  ? "emotional awareness and cognitive focus" 
                  : "tracking your mental health regularly"}.
              </p>
            </div>
            
            <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg">
              <h3 className="font-medium">Growth opportunities</h3>
              <p className="text-sm mt-1">
                {completedGames.length < totalGamesAvailable 
                  ? "Try completing more mental strength games to build diverse skills." 
                  : "Keep up your journal practice to deepen your self-awareness."}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
