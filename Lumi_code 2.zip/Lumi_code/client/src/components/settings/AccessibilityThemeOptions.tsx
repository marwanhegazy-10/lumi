import { useState } from "react";
import { useTheme } from "@/lib/stores/useTheme";
import type { AccessibilityPreset } from "@/lib/stores/useTheme";
import { 
  Accessibility, 
  Eye, 
  Text, 
  PanelTop, 
  Check,
  MessageSquareMore,
  MousePointer,
  Type,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Define the preset options
const PRESETS: {
  id: AccessibilityPreset;
  name: string;
  description: string;
  icon: React.ReactNode;
}[] = [
  {
    id: "none",
    name: "None",
    description: "Default display settings",
    icon: <Eye className="h-4 w-4" />,
  },
  {
    id: "deuteranopia",
    name: "Deuteranopia",
    description: "Green-red color blindness support",
    icon: <Eye className="h-4 w-4" />,
  },
  {
    id: "protanopia",
    name: "Protanopia",
    description: "Red-green color blindness support",
    icon: <Eye className="h-4 w-4" />,
  },
  {
    id: "tritanopia",
    name: "Tritanopia",
    description: "Blue-yellow color blindness support",
    icon: <Eye className="h-4 w-4" />,
  },
  {
    id: "high-contrast",
    name: "High Contrast",
    description: "Maximized contrast for better readability",
    icon: <PanelTop className="h-4 w-4" />,
  },
  {
    id: "reduced-motion",
    name: "Reduced Motion",
    description: "Minimizes animations and transitions",
    icon: <MousePointer className="h-4 w-4" />,
  },
  {
    id: "dyslexic",
    name: "Dyslexic Font",
    description: "Font designed for readers with dyslexia",
    icon: <Text className="h-4 w-4" />,
  },
];

export default function AccessibilityThemeOptions() {
  const {
    accessibilityPreset,
    highContrast,
    reducedMotion,
    dyslexicFont,
    colorBlindMode,
    largeText,
    setAccessibilityPreset,
    toggleHighContrast,
    toggleReducedMotion,
    toggleDyslexicFont,
    setColorBlindMode,
    toggleLargeText,
  } = useTheme();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Accessibility className="h-5 w-5 text-duolingo-purple" />
        <h2 className="text-lg font-bold text-duolingo-darkGray">Accessibility Settings</h2>
      </div>

      <Tabs defaultValue="presets" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="presets" className="flex items-center gap-1">
            <Sparkles className="h-4 w-4" />
            Presets
          </TabsTrigger>
          <TabsTrigger value="custom" className="flex items-center gap-1">
            <Accessibility className="h-4 w-4" />
            Custom
          </TabsTrigger>
        </TabsList>

        {/* Preset options tab */}
        <TabsContent value="presets" className="space-y-4">
          <p className="text-sm text-muted-foreground mb-3">
            Select a preset that works best for your needs. These are specially designed for different forms of visual processing.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {PRESETS.map((preset) => (
              <TooltipProvider key={preset.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant={accessibilityPreset === preset.id ? "default" : "outline"}
                      className={`justify-start h-auto py-3 px-4 ${
                        accessibilityPreset === preset.id
                          ? "bg-duolingo-green text-white"
                          : ""
                      }`}
                      onClick={() => setAccessibilityPreset(preset.id)}
                    >
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-2">
                          {preset.icon}
                          <span>{preset.name}</span>
                        </div>
                        {accessibilityPreset === preset.id && <Check className="h-4 w-4" />}
                      </div>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{preset.description}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </TabsContent>

        {/* Custom options tab */}
        <TabsContent value="custom" className="space-y-4">
          <p className="text-sm text-muted-foreground mb-3">
            Customize individual accessibility settings to fit your specific needs.
          </p>

          <div className="space-y-3 rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PanelTop className="h-4 w-4 text-duolingo-blue" />
                <Label htmlFor="high-contrast" className="text-sm">High Contrast</Label>
              </div>
              <Switch
                id="high-contrast"
                checked={highContrast}
                onCheckedChange={toggleHighContrast}
                className="data-[state=checked]:bg-duolingo-green"
              />
            </div>
            <div className="text-xs text-muted-foreground ml-6">
              Enhances visual contrast for better readability
            </div>
          </div>

          <div className="space-y-3 rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MousePointer className="h-4 w-4 text-duolingo-blue" />
                <Label htmlFor="reduced-motion" className="text-sm">Reduced Motion</Label>
              </div>
              <Switch
                id="reduced-motion"
                checked={reducedMotion}
                onCheckedChange={toggleReducedMotion}
                className="data-[state=checked]:bg-duolingo-green"
              />
            </div>
            <div className="text-xs text-muted-foreground ml-6">
              Minimizes animations and transitions
            </div>
          </div>

          <div className="space-y-3 rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Text className="h-4 w-4 text-duolingo-blue" />
                <Label htmlFor="dyslexic-font" className="text-sm">Dyslexic Font</Label>
              </div>
              <Switch
                id="dyslexic-font"
                checked={dyslexicFont}
                onCheckedChange={toggleDyslexicFont}
                className="data-[state=checked]:bg-duolingo-green"
              />
            </div>
            <div className="text-xs text-muted-foreground ml-6">
              Uses a font designed for readers with dyslexia
            </div>
          </div>

          <div className="space-y-3 rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Type className="h-4 w-4 text-duolingo-blue" />
                <Label htmlFor="large-text" className="text-sm">Large Text</Label>
              </div>
              <Switch
                id="large-text"
                checked={largeText}
                onCheckedChange={toggleLargeText}
                className="data-[state=checked]:bg-duolingo-green"
              />
            </div>
            <div className="text-xs text-muted-foreground ml-6">
              Increases text size for better readability
            </div>
          </div>

          <div className="space-y-3 rounded-lg border p-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Eye className="h-4 w-4 text-duolingo-blue" />
                <Label className="text-sm">Color Blind Mode</Label>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                <Button
                  size="sm"
                  variant={colorBlindMode === "none" ? "default" : "outline"}
                  className={
                    colorBlindMode === "none"
                      ? "bg-duolingo-green text-white"
                      : ""
                  }
                  onClick={() => setColorBlindMode("none")}
                >
                  None
                </Button>
                <Button
                  size="sm"
                  variant={colorBlindMode === "deuteranopia" ? "default" : "outline"}
                  className={
                    colorBlindMode === "deuteranopia"
                      ? "bg-duolingo-green text-white"
                      : ""
                  }
                  onClick={() => setColorBlindMode("deuteranopia")}
                >
                  Deuteranopia
                </Button>
                <Button
                  size="sm"
                  variant={colorBlindMode === "protanopia" ? "default" : "outline"}
                  className={
                    colorBlindMode === "protanopia"
                      ? "bg-duolingo-green text-white"
                      : ""
                  }
                  onClick={() => setColorBlindMode("protanopia")}
                >
                  Protanopia
                </Button>
                <Button
                  size="sm"
                  variant={colorBlindMode === "tritanopia" ? "default" : "outline"}
                  className={
                    colorBlindMode === "tritanopia"
                      ? "bg-duolingo-green text-white"
                      : ""
                  }
                  onClick={() => setColorBlindMode("tritanopia")}
                >
                  Tritanopia
                </Button>
              </div>
              <div className="text-xs text-muted-foreground">
                Adjusts colors to be distinguishable for people with color vision deficiency
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Helper text */}
      <div className="bg-muted/50 p-3 rounded-lg flex items-start gap-2 text-xs text-muted-foreground">
        <MessageSquareMore className="h-4 w-4 flex-shrink-0 mt-0.5" />
        <div>
          These settings help make the app more accessible for neurodivergent users and those with visual processing differences. Adjusting these settings will change how colors, animations, and text appear throughout the app.
        </div>
      </div>
    </div>
  );
}