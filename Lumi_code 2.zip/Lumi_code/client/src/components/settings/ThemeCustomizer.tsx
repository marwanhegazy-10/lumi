import { useState } from "react";
import { useTheme } from "@/lib/stores/useTheme";
import type { ThemeMood } from "@/lib/stores/useTheme";
import { motion } from "framer-motion";
import {
  Palette,
  Moon,
  Sun,
  Check,
  ChevronsUpDown,
  SunMoon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";

// Available themes
const COLORS = [
  { name: "Aqua", value: "aqua" as const, bg: "bg-[#a8dadc]" },
  { name: "Blue", value: "blue" as const, bg: "bg-blue-500" },
  { name: "Purple", value: "purple" as const, bg: "bg-purple-500" },
  { name: "Green", value: "green" as const, bg: "bg-green-500" },
  { name: "Orange", value: "orange" as const, bg: "bg-orange-500" },
  { name: "Pink", value: "pink" as const, bg: "bg-pink-500" },
  { name: "Teal", value: "teal" as const, bg: "bg-teal-500" },
  { name: "Red", value: "red" as const, bg: "bg-red-500" },
  { name: "Indigo", value: "indigo" as const, bg: "bg-indigo-500" },
];

// Available moods
const MOODS = [
  { name: "Calm", value: "calm" as const, icon: "🌊", description: "Peaceful and serene" },
  { name: "Energetic", value: "energetic" as const, icon: "⚡", description: "Upbeat and motivated" },
  { name: "Focused", value: "focused" as const, icon: "🎯", description: "Concentrated and determined" },
  { name: "Creative", value: "creative" as const, icon: "🎨", description: "Imaginative and inspired" },
  { name: "Balanced", value: "balanced" as const, icon: "☯️", description: "Harmonious and centered" },
];

export default function ThemeCustomizer() {
  const { 
    mode, 
    color, 
    mood, 
    autoAdjustWithMood,
    toggleMode, 
    setColor, 
    setMood,
    toggleAutoAdjust,
    getMoodThemeInfo
  } = useTheme();
  
  const [open, setOpen] = useState(false);
  const moodInfo = getMoodThemeInfo();
  
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-medium flex items-center">
            <Palette className="h-4 w-4 mr-2 text-muted-foreground" />
            Theme
          </h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleMode}
            className="h-8 w-8"
          >
            {mode === "light" ? (
              <Moon className="h-4 w-4" />
            ) : (
              <Sun className="h-4 w-4" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {COLORS.map((item) => (
            <Button
              key={item.value}
              variant="outline"
              size="sm"
              className={`h-8 w-8 rounded-full p-0 ${
                color === item.value && "border-2 border-primary"
              }`}
              style={{
                background: `var(--${item.value}-500)`,
              }}
              onClick={() => setColor(item.value)}
              title={item.name}
            >
              <span className="sr-only">{item.name}</span>
              {color === item.value && (
                <Check className="h-4 w-4 text-white" />
              )}
            </Button>
          ))}
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-medium flex items-center">
            <SunMoon className="h-4 w-4 mr-2 text-muted-foreground" />
            Current Mood
          </h3>
          <div className="flex items-center gap-2">
            <Switch
              id="auto-adjust"
              checked={autoAdjustWithMood}
              onCheckedChange={toggleAutoAdjust}
            />
            <Label htmlFor="auto-adjust" className="text-xs">Auto-adjust theme</Label>
          </div>
        </div>
        
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className="w-full justify-between"
            >
              <div className="flex items-center gap-2">
                <span className="text-lg">{MOODS.find(m => m.value === mood)?.icon}</span>
                <span>
                  {MOODS.find(m => m.value === mood)?.name} 
                  <span className="text-xs text-muted-foreground ml-2">
                    ({MOODS.find(m => m.value === mood)?.description})
                  </span>
                </span>
              </div>
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-full p-0">
            <Command>
              <CommandInput placeholder="Search mood..." />
              <CommandList>
                <CommandEmpty>No mood found.</CommandEmpty>
                <CommandGroup>
                  {MOODS.map((item) => (
                    <CommandItem
                      key={item.value}
                      value={item.value}
                      onSelect={(currentValue) => {
                        const moodValue = currentValue as ThemeMood;
                        setMood(moodValue);
                        setOpen(false);
                      }}
                    >
                      <div className="flex items-center gap-2 w-full">
                        <span className="text-lg">{item.icon}</span>
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-xs text-muted-foreground">{item.description}</div>
                        </div>
                      </div>
                      <Check
                        className={`ml-auto h-4 w-4 ${mood === item.value ? "opacity-100" : "opacity-0"}`}
                      />
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </div>
      
      {autoAdjustWithMood && (
        <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
          <p>This mood uses the <span className="font-medium">{moodInfo.color}</span> theme: {moodInfo.description}</p>
        </div>
      )}
    </div>
  );
}