import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Settings, 
  User, 
  Trash2,
  LogOut
} from "lucide-react";

export default function SettingsPage() {
  const { name, ageGroup, resetProgress, setName } = useMentalApp();
  const [newName, setNewName] = useState(name || "");
  const [isEditingName, setIsEditingName] = useState(false);
  const navigate = useNavigate();
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  const handleResetProgress = () => {
    resetProgress();
    setShowResetConfirm(false);
  };
  
  const logout = () => {
    // This would handle actual logout 
    navigate("/login");
  };
  
  return (
    <div className="min-h-screen pb-8">
      <Header />
      
      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="flex flex-col gap-6 max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Settings className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          </div>
          
          {/* Account settings */}
          <div className="bg-card p-5 rounded-2xl border-2 border-border shadow-sm">
            <h2 className="text-lg font-bold text-foreground mb-4">Account</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-secondary" />
                  <div>
                    <Label className="font-medium">Name</Label>
                    {!isEditingName ? (
                      <p className="text-sm text-muted-foreground">{name || "Not set"}</p>
                    ) : (
                      <div className="mt-2 space-y-2">
                        <Input
                          value={newName}
                          onChange={(e) => setNewName(e.target.value)}
                          className="w-full"
                          placeholder="Enter your name"
                        />
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setIsEditingName(false);
                              setNewName(name || "");
                            }}
                          >
                            Cancel
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              if (newName.trim()) {
                                setName(newName.trim());
                                setIsEditingName(false);
                              }
                            }}
                          >
                            Save
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                {!isEditingName && (
                  <Button 
                    variant="outline" 
                    className="rounded-xl"
                    onClick={() => setIsEditingName(true)}
                  >
                    Change
                  </Button>
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  <div>
                    <Label className="font-medium">Age Group</Label>
                    <p className="text-sm text-muted-foreground">{ageGroup || "Not set"}</p>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  className="rounded-xl"
                  onClick={() => {
                    // Navigate to age select page
                    navigate("/onboarding/age");
                  }}
                >
                  Change
                </Button>
              </div>
            </div>
          </div>
          
          {/* Data management */}
          <div className="bg-card p-5 rounded-2xl border-2 border-border shadow-sm">
            <h2 className="text-lg font-bold text-foreground mb-4">Data & Privacy</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trash2 className="h-5 w-5 text-destructive" />
                  <Label className="font-medium">Reset All Progress</Label>
                </div>
                {!showResetConfirm ? (
                  <Button 
                    variant="outline" 
                    className="text-destructive border-destructive hover:bg-destructive/10 rounded-xl"
                    onClick={() => setShowResetConfirm(true)}
                  >
                    Reset
                  </Button>
                ) : (
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      className="rounded-xl" 
                      onClick={() => setShowResetConfirm(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90 rounded-xl"
                      onClick={handleResetProgress}
                    >
                      Confirm
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Logout button */}
          <Button 
            variant="outline" 
            className="border-destructive text-destructive hover:bg-destructive/10 rounded-xl flex items-center gap-2 w-full justify-center py-3"
            onClick={logout}
          >
            <LogOut className="h-5 w-5" />
            Logout
          </Button>
        </div>
      </main>
    </div>
  );
}