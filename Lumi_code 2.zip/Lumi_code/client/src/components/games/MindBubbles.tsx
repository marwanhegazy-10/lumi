import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { positiveThoughts, negativeThoughts } from "@/lib/prompts";
import { ArrowLeft, X } from "lucide-react";

type Bubble = {
  id: number;
  text: string;
  x: number;
  y: number;
  size: number;
  speed: number;
  isPositive: boolean;
  popped: boolean;
};

export default function MindBubbles() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<"intro" | "playing" | "complete">("intro");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const [canvasSize, setCanvasSize] = useState({ width: 300, height: 500 });
  const animationFrameRef = useRef<number | null>(null);
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playHit, playSuccess } = useAudio();

  // Set up canvas and resize handler
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const container = canvas.parentElement;
        if (container) {
          const width = container.clientWidth;
          const height = Math.min(window.innerHeight * 0.7, 600);
          setCanvasSize({ width, height });
          canvas.width = width;
          canvas.height = height;
        }
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Game timer
  useEffect(() => {
    if (gameState !== "playing") return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setGameState("complete");
          playSuccess();
          completeGame("mind-bubbles");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [gameState, completeGame, playSuccess]);

  // Create bubbles at random intervals
  useEffect(() => {
    if (gameState !== "playing") return;

    const createBubble = () => {
      const isPositive = Math.random() > 0.4;
      const thoughtPool = isPositive ? positiveThoughts : negativeThoughts;
      const text = thoughtPool[Math.floor(Math.random() * thoughtPool.length)];
      const size = Math.random() * 30 + 50;
      
      const newBubble: Bubble = {
        id: Date.now(),
        text,
        x: Math.random() * (canvasSize.width - size),
        y: canvasSize.height + size,
        size,
        speed: Math.random() * 1 + 1,
        isPositive,
        popped: false
      };
      
      setBubbles(prev => [...prev, newBubble]);
    };

    const bubbleInterval = setInterval(createBubble, 2000);
    createBubble(); // Create one immediately
    
    return () => clearInterval(bubbleInterval);
  }, [gameState, canvasSize]);

  // Animation loop
  useEffect(() => {
    if (gameState !== "playing" || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      setBubbles(prev => 
        prev
          .filter(bubble => !bubble.popped && bubble.y + bubble.size > 0)
          .map(bubble => ({
            ...bubble,
            y: bubble.y - bubble.speed
          }))
      );
      
      // Draw bubbles
      bubbles.forEach(bubble => {
        if (bubble.popped) return;
        
        // Draw bubble
        ctx.beginPath();
        ctx.arc(bubble.x + bubble.size/2, bubble.y + bubble.size/2, bubble.size/2, 0, Math.PI * 2);
        ctx.fillStyle = bubble.isPositive ? 'rgba(120, 220, 232, 0.7)' : 'rgba(232, 120, 120, 0.7)';
        ctx.fill();
        ctx.strokeStyle = bubble.isPositive ? 'rgba(100, 200, 212, 0.9)' : 'rgba(212, 100, 100, 0.9)';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Draw text
        ctx.font = `${Math.max(10, bubble.size / 5)}px Inter`;
        ctx.fillStyle = '#333';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Word wrap text
        const maxWidth = bubble.size * 0.9;
        const words = bubble.text.split(' ');
        let line = '';
        let lineHeight = Math.max(12, bubble.size / 4);
        let y = bubble.y + bubble.size/2 - (lineHeight * (words.length - 1) / 2);
        
        words.forEach(word => {
          const testLine = line + word + ' ';
          const metrics = ctx.measureText(testLine);
          if (metrics.width > maxWidth && line !== '') {
            ctx.fillText(line, bubble.x + bubble.size/2, y);
            line = word + ' ';
            y += lineHeight;
          } else {
            line = testLine;
          }
        });
        ctx.fillText(line, bubble.x + bubble.size/2, y);
      });
      
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animationFrameRef.current = requestAnimationFrame(animate);
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [gameState, bubbles, canvasSize]);

  // Handle canvas click/touch
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (gameState !== "playing") return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Get click coordinates
    let x, y;
    if ('touches' in e) {
      const rect = canvas.getBoundingClientRect();
      x = e.touches[0].clientX - rect.left;
      y = e.touches[0].clientY - rect.top;
    } else {
      const rect = canvas.getBoundingClientRect();
      x = e.clientX - rect.left;
      y = e.clientY - rect.top;
    }
    
    // Check collision with bubbles
    setBubbles(prev => {
      let updated = false;
      const newBubbles = prev.map(bubble => {
        if (bubble.popped) return bubble;
        
        const dx = x - (bubble.x + bubble.size/2);
        const dy = y - (bubble.y + bubble.size/2);
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < bubble.size/2) {
          updated = true;
          playHit();
          
          // Update score based on bubble type
          if (bubble.isPositive) {
            setScore(s => s + 10);
          } else {
            setScore(s => Math.max(0, s - 5));
          }
          
          return { ...bubble, popped: true };
        }
        return bubble;
      });
      
      if (!updated) return prev;
      return newBubbles;
    });
  };

  // Start the game
  const startGame = () => {
    setGameState("playing");
    setScore(0);
    setTimeLeft(60);
    setBubbles([]);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4">Mind Bubbles</h1>
            
            {gameState === "intro" && (
              <div className="space-y-4">
                <p>
                  Pop positive thought bubbles (blue) and avoid negative thoughts (red).
                  This game helps you recognize and focus on positive thinking patterns.
                </p>
                <img 
                  src="https://cdn-icons-png.flaticon.com/512/2683/2683274.png" 
                  alt="Mind Bubbles Game" 
                  className="w-32 h-32 mx-auto my-4"
                />
                <div className="flex justify-between items-center text-sm bg-muted p-3 rounded">
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full bg-blue-400 mr-2"></div>
                    <span>Positive thoughts: +10 points</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full bg-red-400 mr-2"></div>
                    <span>Negative thoughts: -5 points</span>
                  </div>
                </div>
                <Button className="w-full" onClick={startGame}>
                  Start Game
                </Button>
              </div>
            )}
            
            {gameState === "playing" && (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>Score: <strong>{score}</strong></div>
                  <div>Time: <strong>{timeLeft}s</strong></div>
                </div>
                
                <Progress value={(timeLeft / 60) * 100} className="h-2" />
                
                <div className="relative bg-muted rounded-lg overflow-hidden" style={{ height: canvasSize.height }}>
                  <canvas 
                    ref={canvasRef} 
                    width={canvasSize.width} 
                    height={canvasSize.height}
                    onClick={handleCanvasClick}
                    onTouchStart={handleCanvasClick}
                    className="touch-none"
                  />
                </div>
                
                <p className="text-sm text-muted-foreground">
                  Tap on positive thoughts (blue bubbles) and avoid negative ones (red bubbles).
                </p>
              </div>
            )}
            
            {gameState === "complete" && (
              <div className="space-y-4 text-center">
                <h2 className="text-xl font-semibold">Game Complete!</h2>
                <div className="bg-muted p-6 rounded-lg">
                  <p className="text-lg">Your Score</p>
                  <p className="text-4xl font-bold text-primary">{score}</p>
                </div>
                
                <div className="text-left bg-primary/10 p-4 rounded-lg">
                  <h3 className="font-semibold">What you learned:</h3>
                  <p className="mt-2">
                    Just as you focused on positive thought bubbles in the game, in real life, 
                    focusing on positive thoughts can improve your mood and mental strength. 
                    Recognizing negative thoughts is the first step to replacing them with more 
                    helpful ones.
                  </p>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button variant="outline" className="flex-1" onClick={() => navigate("/dashboard")}>
                    Back to Dashboard
                  </Button>
                  <Button className="flex-1" onClick={startGame}>
                    Play Again
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
