import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Trophy } from "lucide-react";

type Symbol = "circle" | "square" | "triangle" | "star";
type Target = {
  symbol: Symbol;
  color: string;
};

type GameItem = {
  id: number;
  symbol: Symbol;
  color: string;
};

const SYMBOLS: Symbol[] = ["circle", "square", "triangle", "star"];
const COLORS: string[] = ["red", "blue", "green", "purple", "orange"];

const SHAPES = {
  circle: (color: string) => (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="40" fill={color} />
    </svg>
  ),
  square: (color: string) => (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="80" height="80" fill={color} />
    </svg>
  ),
  triangle: (color: string) => (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <polygon points="50,10 90,90 10,90" fill={color} />
    </svg>
  ),
  star: (color: string) => (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <polygon points="50,10 61,35 90,35 65,50 75,80 50,65 25,80 35,50 10,35 39,35" fill={color} />
    </svg>
  ),
};

export default function FocusChallenge() {
  const [gameState, setGameState] = useState<"intro" | "playing" | "complete">("intro");
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [target, setTarget] = useState<Target>({ symbol: "circle", color: "red" });
  const [items, setItems] = useState<GameItem[]>([]);
  const [streak, setStreak] = useState(0);
  const gridRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playHit, playSuccess } = useAudio();

  // Set up game for current level
  useEffect(() => {
    if (gameState !== "playing") return;
    
    // Generate new target
    const randomSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const randomColor = COLORS[Math.floor(Math.random() * COLORS.length)];
    setTarget({ symbol: randomSymbol, color: randomColor });
    
    // Generate items based on level
    const count = 6 + (level * 2);
    const targetCount = Math.floor(count * 0.4); // 40% of items are targets
    
    const newItems: GameItem[] = [];
    
    // Add target items
    for (let i = 0; i < targetCount; i++) {
      newItems.push({
        id: i,
        symbol: randomSymbol,
        color: randomColor
      });
    }
    
    // Add distractor items
    for (let i = targetCount; i < count; i++) {
      let distractorSymbol = randomSymbol;
      let distractorColor = randomColor;
      
      // Make sure at least one property is different
      const changeProperty = Math.random() > 0.5 ? 'symbol' : 'color';
      
      if (changeProperty === 'symbol') {
        while (distractorSymbol === randomSymbol) {
          distractorSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
        }
      } else {
        while (distractorColor === randomColor) {
          distractorColor = COLORS[Math.floor(Math.random() * COLORS.length)];
        }
      }
      
      newItems.push({
        id: i,
        symbol: distractorSymbol,
        color: distractorColor
      });
    }
    
    // Shuffle items
    const shuffledItems = newItems.sort(() => 0.5 - Math.random());
    setItems(shuffledItems);
    
    // Reset timer
    setTimeLeft(30);
    
  }, [gameState, level]);

  // Game timer
  useEffect(() => {
    if (gameState !== "playing") return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          // Time ran out
          setGameState("complete");
          playSuccess();
          completeGame("focus");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [gameState, completeGame, playSuccess]);

  const startGame = () => {
    setGameState("playing");
    setLevel(1);
    setScore(0);
    setStreak(0);
  };

  const handleItemClick = (item: GameItem) => {
    if (gameState !== "playing") return;
    
    // Check if the item matches the target
    const isTarget = item.symbol === target.symbol && item.color === target.color;
    
    if (isTarget) {
      // Correct!
      playHit();
      setScore(prev => prev + 10 + streak * 2);
      setStreak(prev => prev + 1);
      
      // Filter out this item
      setItems(prev => prev.filter(i => i.id !== item.id));
      
      // Check if all targets are cleared
      const remainingTargets = items.filter(i => 
        i.id !== item.id && i.symbol === target.symbol && i.color === target.color
      );
      
      if (remainingTargets.length === 0) {
        // Level complete!
        setLevel(prev => prev + 1);
      }
    } else {
      // Incorrect
      setScore(prev => Math.max(0, prev - 5));
      setStreak(0);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4">Focus Challenge</h1>
            
            {gameState === "intro" && (
              <div className="space-y-4">
                <p>
                  Train your attention and focus by finding all matching shapes as quickly as possible.
                  This game helps improve concentration and mental filtering.
                </p>
                <div className="flex justify-center my-6">
                  <div className="grid grid-cols-4 gap-4">
                    {Object.entries(SHAPES).map(([shapeKey, renderShape]) => (
                      <div key={shapeKey} className="w-16 h-16">
                        {renderShape(COLORS[Math.floor(Math.random() * COLORS.length)])}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-muted p-4 rounded-lg space-y-2">
                  <p className="font-medium">How to play:</p>
                  <ul className="list-disc pl-5 text-sm">
                    <li>Find and click all objects that match the target shape AND color</li>
                    <li>Correct matches earn points (10 points + streak bonus)</li>
                    <li>Incorrect clicks lose points and reset your streak</li>
                    <li>Complete levels as quickly as you can before time runs out</li>
                  </ul>
                </div>
                <Button className="w-full" onClick={startGame}>
                  Start Game
                </Button>
              </div>
            )}
            
            {gameState === "playing" && (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>Level: <strong>{level}</strong></div>
                  <div>Score: <strong>{score}</strong></div>
                  <div>Time: <strong>{timeLeft}s</strong></div>
                </div>
                
                <Progress value={(timeLeft / 30) * 100} className="h-2" />
                
                <div className="bg-muted p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium mb-1">Find all:</p>
                      <div className="flex items-center">
                        <div className="w-10 h-10 mr-2">
                          {SHAPES[target.symbol](target.color)}
                        </div>
                        <div>
                          <span className="font-semibold capitalize">{target.color}</span>
                          <span className="mx-1">+</span>
                          <span className="font-semibold capitalize">{target.symbol}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-sm font-medium mb-1">Streak</p>
                      <span className="text-xl font-bold">{streak}x</span>
                    </div>
                  </div>
                </div>
                
                <div 
                  ref={gridRef}
                  className="grid grid-cols-3 sm:grid-cols-4 gap-4 p-2 bg-gray-50 rounded-lg"
                >
                  {items.map((item) => (
                    <button
                      key={item.id}
                      className="aspect-square bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-2"
                      onClick={() => handleItemClick(item)}
                    >
                      {SHAPES[item.symbol](item.color)}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {gameState === "complete" && (
              <div className="space-y-4 text-center">
                <h2 className="text-xl font-semibold">Game Complete!</h2>
                <div className="flex justify-center">
                  <Trophy className="h-16 w-16 text-yellow-500" />
                </div>
                <div className="bg-muted p-6 rounded-lg">
                  <p className="text-lg">Final Score</p>
                  <p className="text-4xl font-bold text-primary">{score}</p>
                  <p className="text-lg mt-2">Levels Completed</p>
                  <p className="text-2xl font-semibold">{level - 1}</p>
                </div>
                
                <div className="text-left bg-primary/10 p-4 rounded-lg">
                  <h3 className="font-semibold">What you learned:</h3>
                  <p className="mt-2">
                    Focus games like this train your brain to filter out distractions and concentrate 
                    on specific information. This skill is valuable for studying, working, and managing 
                    stress in daily life.
                  </p>
                  <p className="mt-2">
                    The more you practice focused attention, the easier it becomes to stay on task 
                    and filter out unimportant information.
                  </p>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button variant="outline" className="flex-1" onClick={() => navigate("/dashboard")}>
                    Back to Dashboard
                  </Button>
                  <Button className="flex-1" onClick={startGame}>
                    Play Again
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
