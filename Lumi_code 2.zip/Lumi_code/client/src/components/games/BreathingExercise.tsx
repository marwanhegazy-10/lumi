import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowLeftCircle, ArrowRightCircle, PlayCircle, PauseCircle } from "lucide-react";

type BreathingState = "inhale" | "hold" | "exhale" | "rest";

export default function BreathingExercise() {
  const [started, setStarted] = useState(false);
  const [paused, setPaused] = useState(false);
  const [breathingState, setBreathingState] = useState<BreathingState>("inhale");
  const [timer, setTimer] = useState(4); // seconds for current state
  const [circleSize, setCircleSize] = useState(100); // size in pixels
  const [cycles, setCycles] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const animationRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(0);
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playSuccess } = useAudio();

  // Animation frame handler for smooth animation
  const animate = (timestamp: number) => {
    if (!lastUpdateRef.current) lastUpdateRef.current = timestamp;
    
    const elapsed = timestamp - lastUpdateRef.current;
    
    if (elapsed > 50) { // Update roughly every 50ms for smoother animation
      lastUpdateRef.current = timestamp;
      
      if (!paused) {
        // Update timer
        setTimer(prev => {
          const newTime = Math.max(0, prev - 0.05);
          return newTime;
        });
        
        // Update circle size based on breathing state
        if (breathingState === "inhale") {
          setCircleSize(prev => Math.min(300, prev + 1));
        } else if (breathingState === "exhale") {
          setCircleSize(prev => Math.max(100, prev - 1));
        }
        
        // Update total session time
        setTotalTime(prev => prev + 0.05);
      }
    }
    
    animationRef.current = requestAnimationFrame(animate);
  };

  // Start animation loop
  useEffect(() => {
    if (started && !paused) {
      animationRef.current = requestAnimationFrame(animate);
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [started, paused]);

  // Handle breathing state transitions
  useEffect(() => {
    if (!started || paused) return;
    
    if (timer <= 0) {
      // Transition to next breathing state
      switch (breathingState) {
        case "inhale":
          setBreathingState("hold");
          setTimer(7); // hold for 7 seconds
          break;
        case "hold":
          setBreathingState("exhale");
          setTimer(8); // exhale for 8 seconds
          break;
        case "exhale":
          // Check if we should complete a cycle
          if (cycles < 4) {
            setBreathingState("rest");
            setTimer(1); // brief rest
          } else {
            // Exercise complete after 5 cycles
            if (animationRef.current) {
              cancelAnimationFrame(animationRef.current);
            }
            setStarted(false);
            playSuccess();
            completeGame("breathing");
          }
          break;
        case "rest":
          setBreathingState("inhale");
          setTimer(4); // inhale for 4 seconds
          setCycles(prev => prev + 1);
          break;
      }
    }
  }, [timer, breathingState, cycles, started, paused, completeGame, playSuccess]);

  // Start or pause the exercise
  const toggleExercise = () => {
    if (!started) {
      // Start new session
      setStarted(true);
      setPaused(false);
      setBreathingState("inhale");
      setTimer(4);
      setCircleSize(100);
      setCycles(0);
      setTotalTime(0);
    } else {
      // Toggle pause
      setPaused(prev => !prev);
    }
  };

  // Reset the exercise
  const resetExercise = () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    setStarted(false);
    setPaused(false);
    setBreathingState("inhale");
    setTimer(4);
    setCircleSize(100);
    setCycles(0);
    setTotalTime(0);
  };

  // Format time as mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Get instruction text based on current breathing state
  const getInstructionText = () => {
    switch (breathingState) {
      case "inhale": return "Breathe in...";
      case "hold": return "Hold...";
      case "exhale": return "Breathe out...";
      case "rest": return "And relax...";
    }
  };

  // Get color class based on current breathing state
  const getColorClass = () => {
    switch (breathingState) {
      case "inhale": return "from-blue-300 to-purple-500";
      case "hold": return "from-purple-500 to-purple-700";
      case "exhale": return "from-purple-500 to-blue-300";
      case "rest": return "from-blue-200 to-blue-300";
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4">Breathing Exercise</h1>
            
            {!started ? (
              <div className="space-y-4">
                <p>
                  Deep breathing is a simple but powerful relaxation technique that can help reduce 
                  stress and anxiety, increase focus, and improve overall well-being.
                </p>
                <p>
                  This exercise uses the 4-7-8 breathing technique (inhale for 4 seconds, hold for 7 seconds, 
                  exhale for 8 seconds). We'll guide you through 5 cycles.
                </p>
                
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 text-center my-6">
                  <div className="flex justify-center items-center">
                    <img 
                      src="https://cdn-icons-png.flaticon.com/512/3043/3043918.png" 
                      alt="Breathing Exercise" 
                      className="w-32 h-32 mx-auto mb-4" 
                    />
                  </div>
                  <p className="text-sm font-medium">
                    Find a comfortable position, sit upright, and try to relax your body
                  </p>
                </div>
                
                <Button className="w-full" onClick={toggleExercise}>
                  Start Breathing Exercise
                </Button>
              </div>
            ) : (
              <div className="space-y-4 text-center">
                <div className="flex justify-between text-sm mb-4">
                  <div>
                    Cycle: <strong>{cycles + 1}/5</strong>
                  </div>
                  <div>
                    Time: <strong>{formatTime(totalTime)}</strong>
                  </div>
                </div>
                
                {/* Breathing animation */}
                <div className="relative h-80 flex justify-center items-center">
                  <div 
                    className={`absolute rounded-full bg-gradient-radial ${getColorClass()} shadow-lg transition-all duration-100 ease-linear flex items-center justify-center`}
                    style={{ 
                      width: `${circleSize}px`, 
                      height: `${circleSize}px`,
                      opacity: 0.7
                    }}
                  >
                    <div className="text-white text-2xl font-light">
                      {Math.ceil(timer)}
                    </div>
                  </div>
                </div>
                
                <div className="text-xl font-medium mt-4">
                  {getInstructionText()}
                </div>
                
                <div className="flex justify-center gap-4 mt-6">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={resetExercise}
                    className="rounded-full h-14 w-14"
                  >
                    <ArrowLeftCircle className="h-7 w-7" />
                  </Button>
                  
                  <Button 
                    size="icon" 
                    onClick={toggleExercise}
                    className="rounded-full h-14 w-14 bg-primary-foreground text-primary hover:bg-primary hover:text-primary-foreground"
                  >
                    {paused ? (
                      <PlayCircle className="h-7 w-7" />
                    ) : (
                      <PauseCircle className="h-7 w-7" />
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={() => navigate("/dashboard")}
                    className="rounded-full h-14 w-14"
                  >
                    <ArrowRightCircle className="h-7 w-7" />
                  </Button>
                </div>
                
                {paused && (
                  <div className="p-3 bg-muted rounded-md mt-4">
                    <p className="text-sm">
                      Exercise paused. Press the play button to continue.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Tips section */}
          <div className="bg-card p-6 rounded-xl shadow mt-6">
            <h2 className="text-xl font-semibold mb-3">Benefits of Deep Breathing</h2>
            <ul className="space-y-2 list-disc pl-5">
              <li>Reduces stress and anxiety</li>
              <li>Lowers heart rate and blood pressure</li>
              <li>Improves concentration and focus</li>
              <li>Helps manage emotional responses</li>
              <li>Can be done anywhere, anytime you need to calm down</li>
            </ul>
            
            <div className="mt-4 p-3 bg-amber-50 border border-amber-100 rounded-lg">
              <p className="text-sm">
                <strong>Tip:</strong> Try to practice deep breathing for a few minutes each day to build this skill.
                Over time, you'll find it easier to use this technique when feeling stressed or overwhelmed.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
