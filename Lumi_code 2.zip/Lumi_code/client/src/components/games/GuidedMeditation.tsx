import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import { motion, AnimatePresence } from "framer-motion";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Play, Pause, VolumeX, Volume2, RefreshCw } from "lucide-react";

// Define meditation types
type MeditationCategory = "focus" | "calm" | "sleep" | "confidence";

interface Meditation {
  id: string;
  title: string;
  description: string;
  category: MeditationCategory;
  duration: number; // in seconds
  backgroundSound?: string;
  script: {
    time: number; // time in seconds when this script should be read
    text: string;
  }[];
}

// Sample meditations
const MEDITATIONS: Meditation[] = [
  {
    id: "breathing-focus",
    title: "Focused Breathing",
    description: "A simple meditation focusing on your breath to bring clarity and focus.",
    category: "focus",
    duration: 180, // 3 minutes
    backgroundSound: "/sounds/background.mp3",
    script: [
      { time: 0, text: "Find a comfortable position and gently close your eyes." },
      { time: 5, text: "Take a deep breath in through your nose..." },
      { time: 10, text: "And slowly exhale through your mouth." },
      { time: 15, text: "Notice the sensation of your breath as it moves in and out of your body." },
      { time: 25, text: "Breathe in... counting to 4..." },
      { time: 30, text: "Hold for 1..." },
      { time: 32, text: "And exhale for 6..." },
      { time: 40, text: "Continue this pattern, focusing only on your breath." },
      { time: 60, text: "If your mind wanders, gently bring your attention back to your breathing." },
      { time: 90, text: "Breathe in... feeling the air fill your lungs..." },
      { time: 100, text: "Breathe out... releasing any tension..." },
      { time: 120, text: "With each breath, feel yourself becoming more present and focused." },
      { time: 150, text: "Take two more deep breaths at your own pace..." },
      { time: 165, text: "And when you're ready, slowly open your eyes, carrying this focus with you." },
      { time: 175, text: "Well done." }
    ]
  },
  {
    id: "body-scan",
    title: "Body Scan",
    description: "A relaxing meditation that helps you release tension throughout your body.",
    category: "calm",
    duration: 180, // 3 minutes for demo, would be longer in reality
    backgroundSound: "/sounds/background.mp3",
    script: [
      { time: 0, text: "Find a comfortable position, sitting or lying down." },
      { time: 5, text: "Take a few deep breaths to settle in." },
      { time: 15, text: "Begin by bringing your attention to the top of your head." },
      { time: 25, text: "Notice any sensations... any tension... any comfort..." },
      { time: 35, text: "Move your attention down to your face. Your forehead, eyes, cheeks, and jaw." },
      { time: 45, text: "If you notice any tension, imagine it melting away with each breath." },
      { time: 60, text: "Continue down to your neck and shoulders, areas where we often hold stress." },
      { time: 70, text: "Breathe into any tightness, allowing it to soften." },
      { time: 85, text: "Move down through your arms to your hands and fingertips." },
      { time: 95, text: "Notice how they feel without trying to change anything." },
      { time: 110, text: "Bring awareness to your chest and upper back." },
      { time: 120, text: "Feel your breath moving in this area." },
      { time: 135, text: "Continue down through your abdomen, lower back, and pelvis." },
      { time: 150, text: "Finally, move your attention through your legs down to your feet." },
      { time: 165, text: "Take a moment to feel your entire body as a whole." },
      { time: 175, text: "Gently wiggle your fingers and toes, and when you're ready, open your eyes." }
    ]
  },
  {
    id: "confidence-boost",
    title: "Confidence Boost",
    description: "Build self-esteem and confidence with this positive meditation.",
    category: "confidence",
    duration: 180, // 3 minutes for demo
    backgroundSound: "/sounds/background.mp3",
    script: [
      { time: 0, text: "Sit comfortably and take a few deep breaths." },
      { time: 10, text: "Bring to mind a time when you felt confident and capable." },
      { time: 20, text: "Remember how you felt in that moment... what you saw... what you heard." },
      { time: 35, text: "Notice the feeling of confidence in your body. Where do you feel it?" },
      { time: 50, text: "With each breath, allow that feeling to grow stronger." },
      { time: 65, text: "Say to yourself: 'I am capable. I am worthy. I believe in myself.'" },
      { time: 80, text: "Imagine yourself handling upcoming challenges with this same confidence." },
      { time: 95, text: "See yourself speaking clearly, standing tall, making decisions with ease." },
      { time: 110, text: "Know that this confidence is always within you, even when it's hard to feel." },
      { time: 125, text: "Take a deep breath and say: 'I have everything I need within me.'" },
      { time: 140, text: "Breathe in confidence... breathe out doubt..." },
      { time: 155, text: "Remember that you can return to this feeling whenever you need it." },
      { time: 170, text: "When you're ready, gently open your eyes, carrying this confidence with you." }
    ]
  },
  {
    id: "sleep-well",
    title: "Sleep Well",
    description: "A gentle meditation to help you relax and prepare for restful sleep.",
    category: "sleep",
    duration: 180, // 3 minutes for demo, would be longer in reality
    backgroundSound: "/sounds/background.mp3",
    script: [
      { time: 0, text: "Find a comfortable position lying down." },
      { time: 10, text: "Take a deep breath in... and a long, slow breath out..." },
      { time: 20, text: "Feel your body becoming heavier with each exhale." },
      { time: 30, text: "Release any tension in your shoulders... your jaw... your hands..." },
      { time: 45, text: "Let each breath be a little deeper, a little slower..." },
      { time: 60, text: "Imagine a peaceful place where you feel safe and calm." },
      { time: 75, text: "It might be a beach... a forest... or somewhere entirely your own." },
      { time: 90, text: "Feel the comfort of this place surrounding you." },
      { time: 105, text: "With each breath, you drift a little deeper into relaxation." },
      { time: 120, text: "There's nothing you need to do right now except rest." },
      { time: 135, text: "Let go of thoughts about tomorrow or yesterday." },
      { time: 150, text: "Your only job is to breathe and rest." },
      { time: 165, text: "Allow yourself to drift, knowing it's safe to let go into sleep." },
      { time: 175, text: "Sleep well..." }
    ]
  }
];

export default function GuidedMeditation() {
  const [selectedTab, setSelectedTab] = useState<MeditationCategory>("focus");
  const [selectedMeditation, setSelectedMeditation] = useState<Meditation | null>(null);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentScriptIndex, setCurrentScriptIndex] = useState(0);
  const [showMessage, setShowMessage] = useState(false);
  const [currentMessage, setCurrentMessage] = useState("");
  const [volume, setVolume] = useState(50);
  const [useBgMusic, setUseBgMusic] = useState(true);
  const [completedTime, setCompletedTime] = useState(0);
  
  const intervalRef = useRef<number | null>(null);
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playSuccess } = useAudio();
  // We'll just use the success sound when meditation completes
  // instead of background music for now
  
  // Filter meditations by selected category
  const filteredMeditations = MEDITATIONS.filter(m => m.category === selectedTab);
  
  // Handle tab change
  const handleTabChange = (value: string) => {
    setSelectedTab(value as MeditationCategory);
    setSelectedMeditation(null);
    resetMeditation();
  };
  
  // Select a meditation
  const handleSelectMeditation = (meditation: Meditation) => {
    setSelectedMeditation(meditation);
    setTimerSeconds(0);
    setCurrentScriptIndex(0);
    setCurrentMessage(meditation.script[0].text);
    setShowMessage(false);
    setIsPlaying(false);
    
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };
  
  // Handle playing and pausing
  const togglePlay = () => {
    if (!selectedMeditation) return;
    
    setIsPlaying(!isPlaying);
    
    if (!isPlaying) {
      // Starting the meditation
      if (timerSeconds === 0) {
        setShowMessage(true);
      }
      
      // Start the timer
      intervalRef.current = window.setInterval(() => {
        setTimerSeconds(prev => {
          const newTime = prev + 1;
          
          // Check if we need to show a new message
          if (selectedMeditation) {
            const nextScriptIndex = selectedMeditation.script.findIndex(
              item => item.time > newTime
            );
            
            const currentIndex = nextScriptIndex === -1 
              ? selectedMeditation.script.length - 1 
              : nextScriptIndex - 1;
            
            if (currentIndex >= 0 && currentIndex !== currentScriptIndex) {
              setCurrentScriptIndex(currentIndex);
              setCurrentMessage(selectedMeditation.script[currentIndex].text);
              setShowMessage(true);
              
              // Hide message after 8 seconds
              setTimeout(() => {
                setShowMessage(false);
              }, 8000);
            }
          }
          
          // Check if meditation is complete
          if (selectedMeditation && newTime >= selectedMeditation.duration) {
            if (intervalRef.current) {
              window.clearInterval(intervalRef.current);
              intervalRef.current = null;
            }
            setIsPlaying(false);
            setCompletedTime(Date.now());
            completeGame("guided-meditation");
            
            return selectedMeditation.duration;
          }
          
          return newTime;
        });
      }, 1000);
    } else {
      // Stop the timer
      if (intervalRef.current) {
        window.clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
  };
  
  // Volume change now just stores the value for when we implement real audio
  
  // Success sound when meditation completes
  useEffect(() => {
    if (completedTime > 0) {
      playSuccess();
    }
  }, [completedTime, playSuccess]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        window.clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  // Reset meditation state
  const resetMeditation = () => {
    setTimerSeconds(0);
    setCurrentScriptIndex(0);
    setShowMessage(false);
    setIsPlaying(false);
    
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  // Calculate progress percentage
  const progressPercentage = selectedMeditation
    ? (timerSeconds / selectedMeditation.duration) * 100
    : 0;
    
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4">Guided Meditation</h1>
            
            {completedTime > 0 && (
              <div className="bg-green-50 border border-green-100 rounded-lg p-4 mb-6">
                <h3 className="text-green-800 font-medium">Meditation Complete</h3>
                <p className="text-green-700 text-sm mt-1">Great job taking time for yourself!</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-3"
                  onClick={() => {
                    setCompletedTime(0);
                    resetMeditation();
                  }}
                >
                  <RefreshCw className="h-3 w-3 mr-2" />
                  Start Another
                </Button>
              </div>
            )}
            
            {!selectedMeditation ? (
              <div>
                <Tabs defaultValue={selectedTab} onValueChange={handleTabChange}>
                  <TabsList className="grid grid-cols-4 mb-4">
                    <TabsTrigger value="focus">Focus</TabsTrigger>
                    <TabsTrigger value="calm">Calm</TabsTrigger>
                    <TabsTrigger value="sleep">Sleep</TabsTrigger>
                    <TabsTrigger value="confidence">Confidence</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value={selectedTab} className="mt-0">
                    <div className="grid gap-4">
                      {filteredMeditations.map((meditation) => (
                        <div
                          key={meditation.id}
                          className="border rounded-lg p-4 cursor-pointer hover:border-primary/50 transition-colors"
                          onClick={() => handleSelectMeditation(meditation)}
                        >
                          <h3 className="font-semibold">{meditation.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{meditation.description}</p>
                          <div className="flex items-center mt-3 text-xs text-muted-foreground">
                            <span>{formatTime(meditation.duration)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="mt-6 bg-muted/50 p-4 rounded-lg">
                  <h3 className="font-medium">Benefits of Meditation:</h3>
                  <ul className="mt-2 space-y-1 text-sm pl-5 list-disc">
                    <li>Reduces stress and anxiety</li>
                    <li>Improves focus and concentration</li>
                    <li>Enhances self-awareness</li>
                    <li>Helps manage negative emotions</li>
                    <li>May improve sleep quality</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <h2 className="font-semibold text-lg">{selectedMeditation.title}</h2>
                    <div className="text-muted-foreground">
                      {formatTime(timerSeconds)} / {formatTime(selectedMeditation.duration)}
                    </div>
                  </div>
                  
                  <Progress value={progressPercentage} className="h-2" />
                </div>
                
                <div className="bg-muted/30 rounded-lg overflow-hidden relative min-h-[200px] flex items-center justify-center">
                  <AnimatePresence>
                    {showMessage && (
                      <motion.div
                        className="text-center max-w-md mx-auto p-6"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.5 }}
                      >
                        <p className="text-lg">{currentMessage}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                
                <div className="flex justify-center space-x-4">
                  <Button
                    size="icon"
                    className="h-12 w-12 rounded-full"
                    onClick={togglePlay}
                  >
                    {isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6" />
                    )}
                  </Button>
                </div>
                
                <div className="space-y-4 border-t pt-4 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                      <div className="w-[120px]">
                        <Slider 
                          value={[volume]} 
                          max={100} 
                          step={1}
                          onValueChange={(value) => setVolume(value[0])} 
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="bg-music" 
                        checked={useBgMusic}
                        onCheckedChange={setUseBgMusic}
                      />
                      <Label htmlFor="bg-music">Background Music</Label>
                    </div>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => {
                      setSelectedMeditation(null);
                      resetMeditation();
                    }}
                  >
                    Choose Another Meditation
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}