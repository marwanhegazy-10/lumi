import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Check, X, AlertCircle, CheckCircle2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/layout/Header";

// Types
type ReframingQuestion = {
  id: number;
  negativeThought: string;
  reframingOptions: {
    text: string;
    isCorrect: boolean;
    explanation: string;
  }[];
};

// Sample questions
const questions: ReframingQuestion[] = [
  {
    id: 1,
    negativeThought: "I completely failed that presentation. I'm terrible at public speaking.",
    reframingOptions: [
      {
        text: "Everyone thinks I'm a failure now.",
        isCorrect: false,
        explanation: "This is an over-generalization. You can't know what everyone thinks, and a single presentation doesn't define your abilities."
      },
      {
        text: "Public speaking is challenging, but I can learn from this experience and improve next time.",
        isCorrect: true,
        explanation: "This reframes the situation as an opportunity for growth rather than a permanent failure."
      },
      {
        text: "I'll just avoid all presentations in the future.",
        isCorrect: false,
        explanation: "This is avoidance thinking, which prevents growth and can increase anxiety over time."
      }
    ]
  },
  {
    id: 2,
    negativeThought: "My friend didn't respond to my text. They must be mad at me.",
    reframingOptions: [
      {
        text: "They're probably busy and will respond when they can.",
        isCorrect: true,
        explanation: "This considers other possible explanations rather than jumping to the worst conclusion."
      },
      {
        text: "I always say the wrong things to people.",
        isCorrect: false,
        explanation: "This is overgeneralizing and mind reading. There's no evidence to support this thought."
      },
      {
        text: "I'll never text them again since they're ignoring me.",
        isCorrect: false,
        explanation: "This is all-or-nothing thinking and assumes the worst without evidence."
      }
    ]
  },
  {
    id: 3,
    negativeThought: "I made a mistake on my assignment. I'm going to fail the entire course.",
    reframingOptions: [
      {
        text: "Everyone makes mistakes. I'll learn from this and do better on the next assignment.",
        isCorrect: true,
        explanation: "This normalizes mistakes as part of learning and focuses on improvement."
      },
      {
        text: "I'm just not smart enough for this course.",
        isCorrect: false,
        explanation: "This is labeling yourself negatively based on a single event, which isn't accurate or helpful."
      },
      {
        text: "The teacher probably thinks I don't care about the class now.",
        isCorrect: false,
        explanation: "This is mind reading and catastrophizing. One mistake doesn't define your teacher's opinion of you."
      }
    ]
  },
  {
    id: 4,
    negativeThought: "Nobody talked to me at the party. I must be boring and unlikable.",
    reframingOptions: [
      {
        text: "Everyone at parties is judging me.",
        isCorrect: false,
        explanation: "This is mind reading and overgeneralizing. Most people are focused on themselves, not judging you."
      },
      {
        text: "I'll never go to another social event again.",
        isCorrect: false,
        explanation: "This is an extreme reaction that limits your opportunities for positive experiences."
      },
      {
        text: "Social situations can be challenging. Next time, I might try initiating conversations instead of waiting for others.",
        isCorrect: true,
        explanation: "This acknowledges the difficulty while suggesting a constructive approach for the future."
      }
    ]
  },
  {
    id: 5,
    negativeThought: "I didn't get the job I applied for. I'll never find a good job.",
    reframingOptions: [
      {
        text: "Job searching takes time, and rejection is part of the process for everyone.",
        isCorrect: true,
        explanation: "This normalizes rejection as part of the job search process rather than a personal failure."
      },
      {
        text: "I'm obviously not qualified for any good jobs.",
        isCorrect: false,
        explanation: "This overgeneralizes from one rejection to all future job prospects, which isn't logical."
      },
      {
        text: "The interviewer probably thought I was incompetent.",
        isCorrect: false,
        explanation: "This is mind reading. Job decisions are based on many factors, not just your performance."
      }
    ]
  }
];

export default function ThoughtReframing() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [gameComplete, setGameComplete] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playSuccess, playError, playClick } = useAudio();
  
  const handleOptionSelect = (index: number) => {
    if (selectedOption !== null) return; // Prevent changing answer
    
    playClick();
    setSelectedOption(index);
    
    const correct = questions[currentQuestion].reframingOptions[index].isCorrect;
    setIsCorrect(correct);
    
    if (correct) {
      playSuccess();
      setScore(score + 1);
    } else {
      playError();
    }
    
    // Show explanation
    setShowExplanation(true);
  };
  
  const handleNextQuestion = () => {
    playClick();
    setSelectedOption(null);
    setIsCorrect(null);
    setShowExplanation(false);
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setGameComplete(true);
      completeGame("thought-reframing");
    }
  };
  
  const handleRestart = () => {
    playClick();
    setCurrentQuestion(0);
    setSelectedOption(null);
    setIsCorrect(null);
    setScore(0);
    setGameComplete(false);
    setShowExplanation(false);
  };
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card rounded-xl shadow p-6">
            <h1 className="text-2xl font-bold mb-2">Thought Reframing</h1>
            <p className="text-muted-foreground mb-6">
              Practice turning negative thoughts into more balanced, helpful perspectives.
            </p>
            
            {!gameComplete ? (
              <div className="space-y-6">
                <div className="flex justify-between items-center text-sm">
                  <div>
                    Question {currentQuestion + 1} of {questions.length}
                  </div>
                  <div>
                    Score: {score}
                  </div>
                </div>
                
                <Card className="border-l-4 border-l-orange-500">
                  <CardContent className="p-4">
                    <h2 className="font-medium mb-1">Negative Thought:</h2>
                    <p className="text-lg">"{questions[currentQuestion].negativeThought}"</p>
                  </CardContent>
                </Card>
                
                <div className="space-y-3">
                  <h2 className="font-medium">Choose a healthier way to reframe this thought:</h2>
                  
                  {questions[currentQuestion].reframingOptions.map((option, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedOption === index
                            ? option.isCorrect
                              ? "border-green-500 bg-green-50"
                              : "border-red-500 bg-red-50"
                            : "hover:bg-muted/50"
                        }`}
                        onClick={() => handleOptionSelect(index)}
                      >
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0 mt-0.5">
                            {selectedOption === index ? (
                              option.isCorrect ? (
                                <CheckCircle2 className="h-5 w-5 text-green-500" />
                              ) : (
                                <X className="h-5 w-5 text-red-500" />
                              )
                            ) : (
                              <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/50" />
                            )}
                          </div>
                          <p>{option.text}</p>
                        </div>
                        
                        <AnimatePresence>
                          {showExplanation && selectedOption === index && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="mt-3 pt-3 border-t text-sm"
                            >
                              <p className="flex items-start gap-2">
                                <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                                <span>{option.explanation}</span>
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                {selectedOption !== null && (
                  <div className="flex justify-end">
                    <Button onClick={handleNextQuestion}>
                      {currentQuestion < questions.length - 1 ? (
                        <>
                          Next Question
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Complete Exercise
                          <Check className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 space-y-6">
                <div className="inline-flex items-center justify-center rounded-full bg-green-100 p-6 mb-4">
                  <Check className="h-12 w-12 text-green-600" />
                </div>
                
                <h2 className="text-2xl font-bold">
                  Exercise Complete!
                </h2>
                
                <p className="text-xl">
                  Your score: {score} / {questions.length}
                </p>
                
                <div className="max-w-md mx-auto bg-blue-50 text-blue-800 p-4 rounded-lg text-sm">
                  <p>
                    Reframing negative thoughts is a powerful cognitive behavioral therapy technique 
                    that can help change how you feel by changing how you think about situations.
                  </p>
                </div>
                
                <div className="pt-4 flex gap-4 justify-center">
                  <Button variant="outline" onClick={handleRestart}>
                    Try Again
                  </Button>
                  <Button onClick={() => navigate("/dashboard")}>
                    Return to Dashboard
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}