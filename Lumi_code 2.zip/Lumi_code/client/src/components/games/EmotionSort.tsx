import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useAudio } from "@/lib/stores/useAudio";
import Header from "../layout/Header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ArrowLeft, AlertCircle, CheckCircle2 } from "lucide-react";

type Emotion = {
  id: string;
  label: string;
  category: "positive" | "negative" | "neutral";
  userCategory?: "positive" | "negative" | "neutral";
};

const emotions: Emotion[] = [
  { id: "happy", label: "Happy", category: "positive" },
  { id: "excited", label: "Excited", category: "positive" },
  { id: "peaceful", label: "Peaceful", category: "positive" },
  { id: "grateful", label: "Grateful", category: "positive" },
  { id: "proud", label: "Proud", category: "positive" },
  { id: "sad", label: "Sad", category: "negative" },
  { id: "angry", label: "Angry", category: "negative" },
  { id: "worried", label: "Worried", category: "negative" },
  { id: "frustrated", label: "Frustrated", category: "negative" },
  { id: "disappointed", label: "Disappointed", category: "negative" },
  { id: "curious", label: "Curious", category: "neutral" },
  { id: "surprised", label: "Surprised", category: "neutral" },
  { id: "confused", label: "Confused", category: "neutral" },
  { id: "bored", label: "Bored", category: "negative" },
  { id: "content", label: "Content", category: "positive" },
];

function SortableEmotion({ emotion }: { emotion: Emotion }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: emotion.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  let bgColor = "bg-gray-100";
  if (emotion.userCategory === "positive") bgColor = "bg-green-100 border-green-300";
  else if (emotion.userCategory === "negative") bgColor = "bg-red-100 border-red-300";
  else if (emotion.userCategory === "neutral") bgColor = "bg-blue-100 border-blue-300";

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`p-3 mb-2 rounded-md border cursor-grab active:cursor-grabbing touch-none ${bgColor}`}
    >
      {emotion.label}
    </div>
  );
}

export default function EmotionSort() {
  const [gameState, setGameState] = useState<"intro" | "playing" | "checking" | "complete">("intro");
  const [currentRound, setCurrentRound] = useState(1);
  const [gameEmotions, setGameEmotions] = useState<Emotion[]>([]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [score, setScore] = useState(0);
  const navigate = useNavigate();
  const { completeGame } = useMentalApp();
  const { playHit, playSuccess } = useAudio();

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Set up the game with random emotions
  useEffect(() => {
    if (gameState !== "playing") return;

    // Select random emotions for this round
    const shuffledEmotions = [...emotions]
      .sort(() => 0.5 - Math.random())
      .slice(0, 5)
      .map(emotion => ({ ...emotion, userCategory: undefined }));
    
    setGameEmotions(shuffledEmotions);
    setTimeLeft(60);
  }, [gameState, currentRound]);

  // Game timer
  useEffect(() => {
    if (gameState !== "playing") return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setGameState("checking");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [gameState]);

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (active.id !== over?.id) {
      setGameEmotions((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over?.id);
        
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const startGame = () => {
    setGameState("playing");
    setScore(0);
    setCurrentRound(1);
  };

  const categorizeEmotions = (category: "positive" | "negative" | "neutral") => {
    // Apply the category to the currently selected emotion
    const updatedEmotions = gameEmotions.map((emotion, index) => {
      if (index === 0) {
        return { ...emotion, userCategory: category };
      }
      return emotion;
    });

    // Check if this was the last emotion to categorize
    const remainingUncategorized = updatedEmotions.filter(e => e.userCategory === undefined);
    
    if (remainingUncategorized.length === 0) {
      // All emotions have been categorized, move to checking
      setGameEmotions(updatedEmotions);
      playHit();
      setGameState("checking");
    } else {
      // Move the categorized emotion to the end of the array
      const [first, ...rest] = updatedEmotions;
      setGameEmotions([...rest, first]);
      playHit();
    }
  };

  const checkAnswers = () => {
    let newScore = 0;
    
    // Calculate score based on correct categorizations
    gameEmotions.forEach(emotion => {
      if (emotion.userCategory === emotion.category) {
        newScore += 10;
      }
    });
    
    setScore(prev => prev + newScore);
    
    if (currentRound >= 3) {
      setGameState("complete");
      playSuccess();
      completeGame("emotion-sort");
    } else {
      setCurrentRound(prev => prev + 1);
      setGameState("playing");
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-2xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow">
            <h1 className="text-2xl font-bold mb-4">Emotion Sort</h1>
            
            {gameState === "intro" && (
              <div className="space-y-4">
                <p>
                  Understanding your emotions is an important part of mental health. In this game, 
                  you'll categorize different emotions as positive, negative, or neutral.
                </p>
                <img 
                  src="https://cdn-icons-png.flaticon.com/512/4543/4543193.png" 
                  alt="Emotion Sort Game" 
                  className="w-32 h-32 mx-auto my-4"
                />
                <div className="flex justify-between text-sm">
                  <div className="flex-1 bg-green-100 p-3 rounded mr-2">
                    <h3 className="font-semibold">Positive</h3>
                    <p className="text-xs">Happy, Excited, Grateful</p>
                  </div>
                  <div className="flex-1 bg-red-100 p-3 rounded mr-2">
                    <h3 className="font-semibold">Negative</h3>
                    <p className="text-xs">Sad, Angry, Worried</p>
                  </div>
                  <div className="flex-1 bg-blue-100 p-3 rounded">
                    <h3 className="font-semibold">Neutral</h3>
                    <p className="text-xs">Surprised, Curious</p>
                  </div>
                </div>
                <Button className="w-full" onClick={startGame}>
                  Start Game
                </Button>
              </div>
            )}
            
            {gameState === "playing" && (
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>Round: <strong>{currentRound}/3</strong></div>
                  <div>Score: <strong>{score}</strong></div>
                  <div>Time: <strong>{timeLeft}s</strong></div>
                </div>
                
                <Progress value={(timeLeft / 60) * 100} className="h-2" />
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-center mb-4">
                    Categorize this emotion:
                  </p>
                  
                  <div className="text-center my-6">
                    <div className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded-lg text-xl font-bold">
                      {gameEmotions[0]?.label || "Loading..."}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <Button
                      onClick={() => categorizeEmotions("positive")}
                      variant="outline"
                      className="bg-green-50 border-green-200 hover:bg-green-100"
                    >
                      Positive
                    </Button>
                    <Button
                      onClick={() => categorizeEmotions("negative")}
                      variant="outline"
                      className="bg-red-50 border-red-200 hover:bg-red-100"
                    >
                      Negative
                    </Button>
                    <Button
                      onClick={() => categorizeEmotions("neutral")}
                      variant="outline"
                      className="bg-blue-50 border-blue-200 hover:bg-blue-100"
                    >
                      Neutral
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {gameState === "checking" && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Round {currentRound} Results</h2>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="mb-4">Let's see how you did:</p>
                  
                  <div className="space-y-2">
                    {gameEmotions.map((emotion) => (
                      <div 
                        key={emotion.id} 
                        className={`flex justify-between items-center p-3 rounded-md border ${
                          emotion.userCategory === emotion.category
                            ? "bg-green-50 border-green-200"
                            : "bg-red-50 border-red-200"
                        }`}
                      >
                        <div>
                          <span className="font-medium">{emotion.label}</span>
                          <span className="text-sm text-muted-foreground ml-2">
                            (Actually: {emotion.category})
                          </span>
                        </div>
                        {emotion.userCategory === emotion.category ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-red-500" />
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <Button className="w-full mt-4" onClick={checkAnswers}>
                    {currentRound >= 3 ? "See Final Results" : "Next Round"}
                  </Button>
                </div>
              </div>
            )}
            
            {gameState === "complete" && (
              <div className="space-y-4 text-center">
                <h2 className="text-xl font-semibold">Game Complete!</h2>
                <div className="bg-muted p-6 rounded-lg">
                  <p className="text-lg">Final Score</p>
                  <p className="text-4xl font-bold text-primary">{score}</p>
                </div>
                
                <div className="text-left bg-primary/10 p-4 rounded-lg">
                  <h3 className="font-semibold">What you learned:</h3>
                  <p className="mt-2">
                    Recognizing and categorizing emotions is an important skill for emotional intelligence. 
                    By understanding your emotions, you can better manage your reactions and mental health.
                  </p>
                  <p className="mt-2">
                    Remember that it's normal to experience all types of emotions - both positive and negative. 
                    What matters is how we respond to them.
                  </p>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button variant="outline" className="flex-1" onClick={() => navigate("/dashboard")}>
                    Back to Dashboard
                  </Button>
                  <Button className="flex-1" onClick={startGame}>
                    Play Again
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
