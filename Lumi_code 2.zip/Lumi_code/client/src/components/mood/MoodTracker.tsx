import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { useMoodTracking } from "@/lib/hooks/useMoodTracking";
import Header from "../layout/Header";
import MoodSelector from "./MoodSelector";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Calendar } from "@/components/ui/calendar";
import { ArrowLeft, CalendarDays, TrendingUp } from "lucide-react";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function MoodTracker() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const navigate = useNavigate();
  const { moodEntries, moodStats } = useMoodTracking();
  
  // Function to format dates for display
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }).format(date);
  };
  
  // Function to format dates for chart
  const formatChartDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return formatDate(date);
  };
  
  // Prepare mood data for chart
  const chartData = {
    labels: moodEntries.slice(-14).map(entry => formatChartDate(entry.date)),
    datasets: [
      {
        label: 'Mood Level',
        data: moodEntries.slice(-14).map(entry => entry.value),
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        tension: 0.3,
      },
    ],
  };
  
  const chartOptions = {
    responsive: true,
    scales: {
      y: {
        min: 1,
        max: 5,
        ticks: {
          stepSize: 1,
          callback: function(value: any) {
            const moodLabels: {[key: number]: string} = {
              1: 'Very Low',
              2: 'Low',
              3: 'Neutral',
              4: 'Good',
              5: 'Excellent',
            };
            return moodLabels[value] || value;
          }
        }
      }
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const entry = moodEntries.slice(-14)[context.dataIndex];
            const moodLabels: {[key: number]: string} = {
              1: 'Very Low',
              2: 'Low',
              3: 'Neutral',
              4: 'Good',
              5: 'Excellent',
            };
            return `Mood: ${moodLabels[entry.value] || entry.value} (${entry.mood})`;
          }
        }
      }
    },
  };
  
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <div className="max-w-3xl mx-auto">
          <div className="bg-card p-6 rounded-xl shadow mb-6">
            <h1 className="text-2xl font-bold mb-4">Mood Tracker</h1>
            <p className="mb-6">
              Track how you're feeling each day to notice patterns and understand your emotions better.
            </p>
            
            <div className="bg-muted/30 p-4 rounded-lg mb-6">
              <h2 className="text-lg font-semibold mb-3 flex items-center">
                <CalendarDays className="h-5 w-5 mr-2" />
                How are you feeling today?
              </h2>
              <MoodSelector date={date} />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Your Mood Trends
                </CardTitle>
                <CardDescription>
                  View how your mood has changed over the past 14 days
                </CardDescription>
              </CardHeader>
              <CardContent>
                {moodEntries.length > 0 ? (
                  <Line data={chartData} options={chartOptions} />
                ) : (
                  <div className="text-center py-12 bg-muted/20 rounded-lg">
                    <p>No mood data recorded yet</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Start logging your daily mood to see trends
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Calendar</CardTitle>
                  <CardDescription>
                    Select a date to log your mood
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative calendar-with-today">
                    {/* We'll handle "Today" label with CSS */}
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="rounded-md border"
                      modifiers={{
                        today: new Date(),
                      }}
                      modifiersStyles={{
                        today: {
                          // Remove special styling for today
                        }
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Mood Stats</CardTitle>
                  <CardDescription>
                    Your mood summary
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(moodStats).map(([mood, count]) => (
                      <div key={mood} className="flex justify-between items-center">
                        <span>{mood}</span>
                        <span className="font-medium">{count} days</span>
                      </div>
                    ))}
                    
                    {Object.keys(moodStats).length === 0 && (
                      <p className="text-sm text-muted-foreground py-2">
                        No mood data recorded yet
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Insights</CardTitle>
              <CardDescription>
                Tips for managing your moods
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-3 bg-amber-50 border border-amber-100 rounded-lg">
                  <h3 className="font-medium">When mood is low</h3>
                  <p className="text-sm mt-1">
                    Try physical activity, connecting with friends, or doing an activity you enjoy. 
                    Remember that mood fluctuations are normal and will pass.
                  </p>
                </div>
                
                <div className="p-3 bg-green-50 border border-green-100 rounded-lg">
                  <h3 className="font-medium">When mood is high</h3>
                  <p className="text-sm mt-1">
                    Take note of what factors might be contributing to your positive mood. What activities, 
                    people, or environments seem to boost your mood? Try to incorporate these elements regularly.
                  </p>
                </div>
                
                <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg">
                  <h3 className="font-medium">Notice patterns</h3>
                  <p className="text-sm mt-1">
                    Look for connections between your activities, sleep, exercise, and mood. Understanding 
                    these patterns can help you make adjustments to support better mental health.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
