import { useState, useEffect } from "react";
import { useMoodTracking } from "@/lib/hooks/useMoodTracking";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

interface MoodOption {
  value: number;
  mood: string;
  emoji: string;
  color: string;
}

const moodOptions: MoodOption[] = [
  { value: 1, mood: "Terrible", emoji: "😢", color: "bg-red-100 border-red-300" },
  { value: 2, mood: "Not Great", emoji: "😕", color: "bg-orange-100 border-orange-300" },
  { value: 3, mood: "Okay", emoji: "😐", color: "bg-yellow-100 border-yellow-300" },
  { value: 4, mood: "Good", emoji: "🙂", color: "bg-blue-100 border-blue-300" },
  { value: 5, mood: "Excellent", emoji: "😄", color: "bg-green-100 border-green-300" },
];

interface MoodSelectorProps {
  date?: Date;
  compact?: boolean;
}

export default function MoodSelector({ date = new Date(), compact = false }: MoodSelectorProps) {
  const { addMoodEntry, getMoodForDate } = useMoodTracking();
  const [selectedMood, setSelectedMood] = useState<MoodOption | null>(null);
  const [note, setNote] = useState("");
  const [showNote, setShowNote] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  // Check if there's already a mood entry for this date
  const existingMood = getMoodForDate(date);
  
  // Set selected mood if there's an existing entry
  useEffect(() => {
    if (existingMood) {
      const matchingMood = moodOptions.find(option => option.mood === existingMood.mood);
      if (matchingMood) {
        setSelectedMood(matchingMood);
        setNote(existingMood.note || "");
      }
    }
  }, [existingMood]);
  
  const handleSelectMood = (mood: MoodOption) => {
    setSelectedMood(mood);
    if (compact) {
      // In compact mode, submit immediately
      handleSubmit(mood);
    } else {
      // In full mode, show note field
      setShowNote(true);
    }
  };
  
  const handleSubmit = async (moodToSubmit?: MoodOption) => {
    const mood = moodToSubmit || selectedMood;
    if (!mood) return;
    
    setIsSubmitting(true);
    
    try {
      await addMoodEntry({
        date: date.toISOString(),
        mood: mood.mood,
        value: mood.value,
        emoji: mood.emoji,
        note: note.trim() || undefined
      });
      
      setSubmitted(true);
      
      // Reset form after delay
      setTimeout(() => {
        if (!compact) setSubmitted(false);
      }, 3000);
    } catch (error) {
      console.error("Error saving mood entry:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (submitted) {
    return (
      <div className="text-center py-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-green-50 text-green-700 p-4 rounded-lg inline-flex items-center"
        >
          <Check className="h-5 w-5 mr-2" />
          <span>Mood recorded successfully!</span>
        </motion.div>
      </div>
    );
  }
  
  if (compact) {
    return (
      <div className="flex justify-center gap-2">
        {moodOptions.map((option) => (
          <Button
            key={option.value}
            variant="outline"
            size="sm"
            className={`px-1 h-9 ${
              selectedMood?.value === option.value 
                ? "ring-2 ring-primary ring-offset-2" 
                : ""
            }`}
            onClick={() => handleSelectMood(option)}
            disabled={isSubmitting}
          >
            <span className="text-xl">{option.emoji}</span>
          </Button>
        ))}
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex flex-wrap justify-center gap-3 mb-4">
        {moodOptions.map((option) => (
          <motion.button
            key={option.value}
            className={`flex flex-col items-center rounded-md border p-3 ${option.color} ${
              selectedMood?.value === option.value 
                ? "ring-2 ring-primary ring-offset-2" 
                : "hover:brightness-95"
            }`}
            onClick={() => handleSelectMood(option)}
            disabled={isSubmitting}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="text-3xl mb-1">{option.emoji}</span>
            <span className="text-sm font-medium">{option.mood}</span>
          </motion.button>
        ))}
      </div>
      
      {showNote && selectedMood && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          transition={{ duration: 0.3 }}
          className="mt-4"
        >
          <p className="mb-2 text-sm font-medium">Add a note about why you're feeling {selectedMood.mood.toLowerCase()} (optional)</p>
          <Textarea
            placeholder="What's making you feel this way?"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="mb-3"
            disabled={isSubmitting}
          />
          <Button 
            onClick={() => handleSubmit()}
            disabled={isSubmitting}
            className="w-full sm:w-auto"
          >
            Save Mood
          </Button>
        </motion.div>
      )}
    </div>
  );
}
