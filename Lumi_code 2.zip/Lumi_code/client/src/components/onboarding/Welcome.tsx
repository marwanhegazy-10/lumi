import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Brain, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function Welcome() {
  const [name, setName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { setProfile } = useMentalApp();
  const navigate = useNavigate();

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    
    try {
      // Save the name and navigate to age selection
      setProfile({ name: name.trim() });
      navigate("/age-select");
    } catch (error) {
      console.error("Error starting onboarding:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <motion.div 
          className="w-full max-w-md bg-card p-8 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-8">
            <div className="mx-auto bg-primary/10 rounded-full p-3 w-16 h-16 flex items-center justify-center mb-4">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">Lumi</h1>
            <p className="text-muted-foreground mt-2">
              Your journey to mental strength begins here
            </p>
          </div>

          <form onSubmit={handleStart} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium">
                What's your name?
              </label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                autoFocus
              />
            </div>

            <div className="bg-blue-50 text-blue-800 p-4 rounded-lg text-sm">
              <p>
                Welcome to Lumi! This app will help you build mental strength through fun games and activities.
              </p>
            </div>

            <Button 
              type="submit" 
              className="w-full"
              disabled={!name.trim() || isSubmitting}
            >
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>

          <div className="mt-8 text-center text-xs text-muted-foreground">
            <p>
              Lumi helps young people build mental strength through games, journaling, and tracking.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
