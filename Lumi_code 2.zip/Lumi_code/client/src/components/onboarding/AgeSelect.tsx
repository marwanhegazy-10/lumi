import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { ArrowLeft, ArrowRight, Baby, Blocks, User } from "lucide-react";
import { motion } from "framer-motion";

type AgeGroup = "children" | "teen" | "young-adult";

interface AgeOptionProps {
  id: AgeGroup;
  title: string;
  ageRange: string;
  description: string;
  icon: React.ReactNode;
  selected: boolean;
  onSelect: (id: AgeGroup) => void;
}

function AgeOption({ 
  id, 
  title, 
  ageRange, 
  description, 
  icon, 
  selected, 
  onSelect 
}: AgeOptionProps) {
  const handleClick = () => {
    console.log("Age option clicked:", id);
    onSelect(id);
  };
  
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleClick}
      className="cursor-pointer"
    >
      <Card 
        className={`transition-all ${
          selected 
            ? "border-primary ring-2 ring-primary ring-offset-2" 
            : "hover:border-primary/50"
        }`}
      >
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">{title}</CardTitle>
            <div className={`p-2 rounded-full ${
              selected 
                ? "bg-primary text-primary-foreground" 
                : "bg-muted"
            }`}>
              {icon}
            </div>
          </div>
          <CardDescription>{ageRange}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function AgeSelect() {
  const [selectedAge, setSelectedAge] = useState<AgeGroup | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { name, setAgeGroup, completeOnboarding } = useMentalApp();
  const navigate = useNavigate();

  const handleBack = () => {
    navigate("/");
  };

  const handleContinue = async () => {
    if (!selectedAge) return;
    console.log("Selected age:", selectedAge);
    setIsSubmitting(true);
    
    try {
      // Update age group
      console.log("Setting age group to:", selectedAge);
      setAgeGroup(selectedAge);
      
      // Complete onboarding and navigate to dashboard
      console.log("Completing onboarding");
      completeOnboarding();
      
      // Directly set some default state values
      console.log("Navigating to dashboard");
      navigate("/");
    } catch (error) {
      console.error("Error completing onboarding:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="p-4 border-b">
        <div className="container mx-auto flex justify-between items-center">
          <Button variant="ghost" size="sm" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="text-lg font-medium">Lumi</div>
          <div className="w-[73px]"></div> {/* Spacer to balance layout */}
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-2xl font-bold mb-2">
              Hi {name || 'there'}! Let's personalize your experience
            </h1>
            <p className="text-muted-foreground mb-8">
              Select your age group to get content that's right for you
            </p>
            
            <div className="space-y-4">
              <AgeOption
                id="children"
                title="Children"
                ageRange="Ages 7-12"
                description="Activities with simpler language, playful games, and age-appropriate content to introduce mental wellness concepts."
                icon={<Baby className="h-5 w-5" />}
                selected={selectedAge === "children"}
                onSelect={setSelectedAge}
              />
              
              <AgeOption
                id="teen"
                title="Teenagers"
                ageRange="Ages 13-18"
                description="Content that addresses school stress, social challenges, and growing independence with relatable examples."
                icon={<Blocks className="h-5 w-5" />}
                selected={selectedAge === "teen"}
                onSelect={setSelectedAge}
              />
              
              <AgeOption
                id="young-adult"
                title="Young Adults"
                ageRange="Ages 19-27"
                description="Advanced mental strength techniques focused on career, relationships, and adult responsibilities."
                icon={<User className="h-5 w-5" />}
                selected={selectedAge === "young-adult"}
                onSelect={setSelectedAge}
              />
            </div>
            
            <div className="mt-8">
              <Button 
                onClick={handleContinue}
                disabled={!selectedAge || isSubmitting}
                className="w-full"
              >
                Continue to Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
