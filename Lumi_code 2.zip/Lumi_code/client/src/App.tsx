import { Suspense, useEffect, useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useAudio } from "./lib/stores/useAudio";
import { useMentalApp } from "./lib/stores/useMentalApp";
import { ThemeProvider } from "./lib/stores/useTheme";
import { Loader2 } from "lucide-react";
import StreakNotification from "./components/notifications/StreakNotification";

function App() {
  const { volume } = useAudio();
  const { updateStreak, onboardingCompleted, name } = useMentalApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [isInitialized, setIsInitialized] = useState(false);
  
  // Initialize the app with a more robust approach
  useEffect(() => {
    const initializeApp = async () => {
      try {
        console.log("Initializing Lumi app...");
        
        // Update streaks on app initialization
        updateStreak();
        
        // Mark as initialized
        setIsInitialized(true);
        console.log("Lumi app initialization complete.");
      } catch (error) {
        console.error("Error initializing app:", error);
        // Still mark as initialized to prevent endless loading state
        setIsInitialized(true);
      }
    };
    
    initializeApp();
  }, [updateStreak]);
  
  // Handle routing based on auth state - but only after initialization
  useEffect(() => {
    if (!isInitialized) return;
    
    const isAuthRoute = location.pathname === '/login' || 
                       location.pathname === '/signup' || 
                       location.pathname.includes('onboarding');
    
    // Enhanced routing logic with better logging
    console.log("Checking navigation state:", { 
      name, 
      onboardingCompleted, 
      currentPath: location.pathname,
      isAuthRoute
    });
    
    if (!name && !isAuthRoute) {
      // User not authenticated, redirect to login
      console.log("User not authenticated, redirecting to login");
      navigate('/login');
    } else if (name && !onboardingCompleted && !isAuthRoute) {
      // User authenticated but onboarding not completed
      console.log("Onboarding incomplete, redirecting to age selection");
      navigate('/onboarding/age');
    }
  }, [name, onboardingCompleted, navigate, location, isInitialized]);

  if (!isInitialized) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background font-sans">
        <Suspense fallback={
          <div className="flex h-screen w-full items-center justify-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        }>
          <StreakNotification />
          <Outlet />
        </Suspense>
      </div>
    </ThemeProvider>
  );
}

export default App;
