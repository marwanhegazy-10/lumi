import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import Dashboard from "./components/layout/Dashboard";
import Welcome from "./components/onboarding/Welcome";
import AgeSelect from "./components/onboarding/AgeSelect";
import MindBubbles from "./components/games/MindBubbles";
import EmotionSort from "./components/games/EmotionSort";
import BreathingExercise from "./components/games/BreathingExercise";
import FocusChallenge from "./components/games/FocusChallenge";
import ThoughtReframing from "./components/games/ThoughtReframing";
import GuidedMeditation from "./components/games/GuidedMeditation";
import JournalPrompt from "./components/journal/JournalPrompt";
import GratitudeJournal from "./components/journal/GratitudeJournal";
import MoodTracker from "./components/mood/MoodTracker";
import ProgressPage from "./components/progress/ProgressPage";
import AchievementsPage from "./components/progress/AchievementsPage";
import SettingsPage from "./components/settings/SettingsPage";
import LoginPage from "./components/auth/LoginPage";
import SignupPage from "./components/auth/SignupPage";
import NotFound from "./pages/not-found";

export const router = createBrowserRouter([
  // Auth routes - outside the main app layout
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/signup",
    element: <SignupPage />,
  },
  // Main app routes
  {
    path: "/",
    element: <App />,
    // We'll handle 404s internally and redirect to login as needed
    errorElement: <LoginPage />,
    children: [
      {
        index: true,
        element: <Dashboard />,
      },
      {
        path: "onboarding/welcome",
        element: <Welcome />,
      },
      {
        path: "onboarding/age",
        element: <AgeSelect />,
      },
      {
        path: "settings",
        element: <SettingsPage />,
      },
      {
        path: "games/mind-bubbles",
        element: <MindBubbles />,
      },
      {
        path: "games/emotion-sort",
        element: <EmotionSort />,
      },
      {
        path: "games/breathing",
        element: <BreathingExercise />,
      },
      {
        path: "games/focus",
        element: <FocusChallenge />,
      },
      {
        path: "games/thought-reframing",
        element: <ThoughtReframing />,
      },
      {
        path: "games/guided-meditation",
        element: <GuidedMeditation />,
      },
      {
        path: "journal",
        element: <JournalPrompt />,
      },
      {
        path: "gratitude",
        element: <GratitudeJournal />,
      },
      {
        path: "mood",
        element: <MoodTracker />,
      },
      {
        path: "progress",
        element: <ProgressPage />,
      },
      {
        path: "achievements",
        element: <AchievementsPage />,
      },
      // Add a catch-all route to handle 404s within the app
      {
        path: "*",
        element: <Dashboard />,
      },
    ],
  },
  // Global catch-all route - redirects all unmatched routes to login
  {
    path: "*",
    element: <LoginPage />,
  },
]);
