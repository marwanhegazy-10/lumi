import { LucideIcon } from "lucide-react";

// User profile types
export type AgeGroup = "children" | "teen" | "young-adult";

export interface Profile {
  name?: string;
  ageGroup?: AgeGroup;
  onboardingCompleted?: boolean;
}

// Game related types
export interface Game {
  id: string;
  title: string;
  description: string;
  category: "emotional" | "focus" | "calm" | "cognitive";
  duration: string;
  path: string;
  icon: LucideIcon;
}

// Achievement related types
export interface Achievement {
  id: string;
  name: string;
  description: string;
  criteria?: string;
  reward?: string;
  category: "streak" | "games" | "journal" | "mood";
  unlocked?: boolean;
}

// Journal related types
export interface JournalPrompt {
  id: string;
  text: string;
  helpText?: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  prompt: string;
  content: string;
  mood: string;
}

// Mood tracking related types
export interface MoodEntry {
  date: string;
  mood: string;
  value: number;
  emoji: string;
  note?: string;
}

// User progress types
export interface UserProgress {
  streak: number;
  lastActivity?: string;
  moodStreak: number;
  journalStreak: number;
  achievements: string[];
  moodEntries: MoodEntry[];
  journalEntries: JournalEntry[];
}
