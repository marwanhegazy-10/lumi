import { Game, Achievement } from "./types";
import { Brain, Zap, Cloud, Target } from "lucide-react";

// Game data for different age groups
// Each age group has slightly different descriptions and difficulty levels

const commonGames: Game[] = [
  {
    id: "mind-bubbles",
    title: "Mind Bubbles",
    description: "Pop positive thought bubbles and avoid negative ones to build positive thinking patterns.",
    category: "emotional",
    duration: "2-3 minutes",
    path: "/games/mind-bubbles",
    icon: Brain
  },
  {
    id: "emotion-sort",
    title: "Emotion Sort",
    description: "Categorize different emotions to improve emotional intelligence and awareness.",
    category: "emotional",
    duration: "3-4 minutes",
    path: "/games/emotion-sort",
    icon: Zap
  },
  {
    id: "breathing",
    title: "Breathing Exercise",
    description: "Guided breathing technique to reduce stress and increase calm.",
    category: "calm",
    duration: "4-5 minutes",
    path: "/games/breathing",
    icon: Cloud
  },
  {
    id: "focus",
    title: "Focus Challenge",
    description: "Train your attention by finding matching shapes as quickly as possible.",
    category: "focus",
    duration: "2-3 minutes",
    path: "/games/focus",
    icon: Target
  }
];

// Customize games for children
const childrenGames: Game[] = commonGames.map(game => {
  if (game.id === "mind-bubbles") {
    return {
      ...game,
      description: "Pop the happy bubbles and avoid the sad ones in this fun bubble popping game!",
    };
  } else if (game.id === "emotion-sort") {
    return {
      ...game,
      description: "Learn about feelings by sorting them into happy, sad, or in-between groups.",
    };
  } else if (game.id === "breathing") {
    return {
      ...game,
      description: "Follow the bubble to breathe in and out like a balloon to feel calm and relaxed.",
    };
  } else if (game.id === "focus") {
    return {
      ...game,
      description: "Find all the matching shapes and colors in this fun attention game.",
    };
  }
  return game;
});

// Customize games for teens
const teenGames: Game[] = commonGames.map(game => {
  // Teens get the default descriptions
  return game;
});

// Customize games for young adults
const youngAdultGames: Game[] = commonGames.map(game => {
  if (game.id === "mind-bubbles") {
    return {
      ...game,
      description: "Practice cognitive reframing by selecting positive thoughts and rejecting negative ones.",
    };
  } else if (game.id === "emotion-sort") {
    return {
      ...game,
      description: "Develop emotional granularity by categorizing complex emotional states.",
    };
  } else if (game.id === "breathing") {
    return {
      ...game,
      description: "Master the 4-7-8 breathing technique for stress management and mindfulness.",
    };
  } else if (game.id === "focus") {
    return {
      ...game,
      description: "Enhance selective attention and cognitive filtering with this visual attention task.",
    };
  }
  return game;
});

// Get games appropriate for the user's age group
export function getGames(ageGroup: string): Game[] {
  if (ageGroup === "children") {
    return childrenGames;
  } else if (ageGroup === "teen") {
    return teenGames;
  } else {
    return youngAdultGames;
  }
}

// Get achievements for the app
export function getAchievements(): Achievement[] {
  return [
    {
      id: "streak-3",
      name: "Getting Started",
      description: "Use the app for 3 days in a row",
      criteria: "Complete any activity for 3 consecutive days",
      reward: "Unlocked new color theme",
      category: "streak",
      unlocked: false
    },
    {
      id: "streak-7",
      name: "Consistency Champion",
      description: "Use the app for 7 days in a row",
      criteria: "Complete any activity for 7 consecutive days",
      reward: "Unlocked special journal prompts",
      category: "streak",
      unlocked: false
    },
    {
      id: "all-games",
      name: "Game Master",
      description: "Play all the mental strength games",
      criteria: "Complete each of the four games at least once",
      reward: "+50 bonus points",
      category: "games",
      unlocked: false
    },
    {
      id: "journal-streak-3",
      name: "Reflective Writer",
      description: "Journal for 3 days in a row",
      criteria: "Complete a journal entry for 3 consecutive days",
      reward: "Unlocked advanced prompts",
      category: "journal",
      unlocked: false
    },
    {
      id: "mood-streak-3",
      name: "Emotion Tracker",
      description: "Track your mood for 3 days in a row",
      criteria: "Log your mood for 3 consecutive days",
      reward: "Unlocked mood insights",
      category: "mood",
      unlocked: false
    },
    {
      id: "streak-14",
      name: "Dedication Dynamo",
      description: "Use the app for 14 days in a row",
      criteria: "Complete any activity for 14 consecutive days",
      reward: "Unlocked expert-level games",
      category: "streak",
      unlocked: false
    }
  ];
}
