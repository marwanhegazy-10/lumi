import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AudioState {
  isMuted: boolean;
  volume: number;
  
  // Methods
  playSuccess: () => void;
  playError: () => void;
  playComplete: () => void;
  playClick: () => void;
  playHit: () => void;
  playNotification: () => void;
  setMuted: (muted: boolean) => void;
  setVolume: (volume: number) => void;
  toggleMuted: () => void;
}

// Pre-load audio files
let successSound: HTMLAudioElement | null = null;
let errorSound: HTMLAudioElement | null = null;
let completeSound: HTMLAudioElement | null = null;
let clickSound: HTMLAudioElement | null = null;
let hitSound: HTMLAudioElement | null = null;
let notificationSound: HTMLAudioElement | null = null;

// Initialize audio elements if in browser
if (typeof window !== 'undefined') {
  // Success sound - positive chime
  successSound = new Audio('/sounds/success.mp3');
  
  // Error sound - negative tone
  errorSound = new Audio('/sounds/error.mp3');
  
  // Complete sound - achievement sound
  completeSound = new Audio('/sounds/complete.mp3');
  
  // Click sound - UI interaction
  clickSound = new Audio('/sounds/click.mp3');
  
  // Hit sound for games - bubble pop or similar
  hitSound = new Audio('/sounds/click.mp3'); // Reuse click sound for hit
  
  // Notification sound - alert
  notificationSound = new Audio('/sounds/notification.mp3');
}

export const useAudio = create<AudioState>()(
  persist(
    (set, get) => ({
      isMuted: false,
      volume: 0.5,
      
      playSuccess: () => {
        const { isMuted, volume } = get();
        if (isMuted || !successSound) return;
        
        try {
          successSound.volume = volume;
          successSound.currentTime = 0;
          successSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play success sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing success sound:', error);
        }
      },
      
      playError: () => {
        const { isMuted, volume } = get();
        if (isMuted || !errorSound) return;
        
        try {
          errorSound.volume = volume;
          errorSound.currentTime = 0;
          errorSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play error sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing error sound:', error);
        }
      },
      
      playComplete: () => {
        const { isMuted, volume } = get();
        if (isMuted || !completeSound) return;
        
        try {
          completeSound.volume = volume;
          completeSound.currentTime = 0;
          completeSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play complete sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing complete sound:', error);
        }
      },
      
      playClick: () => {
        const { isMuted, volume } = get();
        if (isMuted || !clickSound) return;
        
        try {
          clickSound.volume = volume * 0.7; // Lower volume for click sounds
          clickSound.currentTime = 0;
          clickSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play click sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing click sound:', error);
        }
      },
      
      playHit: () => {
        const { isMuted, volume } = get();
        if (isMuted || !hitSound) return;
        
        try {
          hitSound.volume = volume * 0.6; // Slightly lower volume for hit sounds
          hitSound.currentTime = 0;
          hitSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play hit sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing hit sound:', error);
        }
      },
      
      playNotification: () => {
        const { isMuted, volume } = get();
        if (isMuted || !notificationSound) return;
        
        try {
          notificationSound.volume = volume;
          notificationSound.currentTime = 0;
          notificationSound.play().catch(() => {
            // Ignore autoplay restrictions
            console.log('Could not play notification sound - autoplay restricted');
          });
        } catch (error) {
          console.error('Error playing notification sound:', error);
        }
      },
      
      setMuted: (muted: boolean) => set({ isMuted: muted }),
      
      setVolume: (volume: number) => set({ volume: Math.max(0, Math.min(1, volume)) }),
      
      toggleMuted: () => set((state) => ({ isMuted: !state.isMuted })),
    }),
    {
      name: 'audio-settings',
    }
  )
);