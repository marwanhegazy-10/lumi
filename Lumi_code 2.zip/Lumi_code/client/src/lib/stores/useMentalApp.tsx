import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import { JournalEntry, MoodEntry, UserProgress } from '../types';

interface MentalAppState {
  // User data
  name: string;
  ageGroup: 'children' | 'teen' | 'young-adult';
  onboardingCompleted: boolean;
  
  // Progress tracking
  userProgress: UserProgress;
  
  // App state
  isLoading: boolean;
  hasError: boolean;
  errorMessage: string | null;
  
  // Actions
  setName: (name: string) => void;
  setAgeGroup: (ageGroup: 'children' | 'teen' | 'young-adult') => void;
  setProfile: (profile: { name?: string; ageGroup?: 'children' | 'teen' | 'young-adult' }) => void;
  completeOnboarding: () => void;
  addJournalEntry: (entry: JournalEntry) => Promise<void>;
  deleteJournalEntry: (entryId: string) => void;
  addMoodEntry: (entry: MoodEntry) => Promise<void>;
  completeGame: (gameId: string) => Promise<void>;
  updateStreak: () => void;
  resetProgress: () => void;
  getStreakInfo: () => { 
    current: number; 
    lastActivity: string | undefined;
    isNewStreak: boolean;
  };
  setError: (message: string | null) => void;
  clearError: () => void;
}

// Helper to check if two dates are the same day
const isSameDay = (date1: Date, date2: Date) => {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
};

// Helper to check if a date is yesterday
const isYesterday = (date: Date, comparedTo = new Date()) => {
  const yesterday = new Date(comparedTo);
  yesterday.setDate(yesterday.getDate() - 1);
  return isSameDay(date, yesterday);
};

export const useMentalApp = create<MentalAppState>()(
  persist(
    (set, get) => ({
      // User data
      name: '',
      ageGroup: 'teen',
      onboardingCompleted: false,
      
      // App state
      isLoading: false,
      hasError: false,
      errorMessage: null,
      
      // Progress tracking
      userProgress: {
        streak: 0,
        lastActivity: undefined,
        moodStreak: 0,
        journalStreak: 0,
        achievements: [],
        moodEntries: [],
        journalEntries: [],
      },
      
      // Actions
      setName: (name: string) => set({ name }),
      
      setAgeGroup: (ageGroup: 'children' | 'teen' | 'young-adult') => set({ ageGroup }),
      
      setProfile: (profile: { name?: string; ageGroup?: 'children' | 'teen' | 'young-adult' }) => {
        const updates: Partial<MentalAppState> = {};
        if (profile.name) updates.name = profile.name;
        if (profile.ageGroup) updates.ageGroup = profile.ageGroup;
        set(updates);
      },
      
      completeOnboarding: () => set({ onboardingCompleted: true }),
      
      addJournalEntry: async (entry: JournalEntry) => {
        // Get current state
        const { userProgress } = get();
        
        // Add new entry
        const entries = [entry, ...userProgress.journalEntries];
        
        // Update journal streak
        let journalStreak = userProgress.journalStreak;
        const today = new Date();
        const lastEntryDate = userProgress.journalEntries.length > 0 
          ? new Date(userProgress.journalEntries[0].date) 
          : undefined;
          
        if (!lastEntryDate || !isSameDay(lastEntryDate, today)) {
          journalStreak += 1;
        }
        
        // Update state
        set({
          userProgress: {
            ...userProgress,
            journalEntries: entries,
            journalStreak,
            lastActivity: new Date().toISOString(),
          }
        });
        
        // Update overall streak
        get().updateStreak();
      },
      
      deleteJournalEntry: (entryId: string) => {
        // Get current state
        const { userProgress } = get();
        
        // Filter out the entry to delete
        const filteredEntries = userProgress.journalEntries.filter(
          entry => entry.id !== entryId
        );
        
        // Update state
        set({
          userProgress: {
            ...userProgress,
            journalEntries: filteredEntries,
          }
        });
      },
      
      addMoodEntry: async (entry: MoodEntry) => {
        // Get current state
        const { userProgress } = get();
        
        // Check if there's already an entry for today
        const today = new Date();
        const todayEntryIndex = userProgress.moodEntries.findIndex(e => 
          isSameDay(new Date(e.date), today)
        );
        
        let entries = [...userProgress.moodEntries];
        
        if (todayEntryIndex >= 0) {
          // Update existing entry for today
          entries[todayEntryIndex] = entry;
        } else {
          // Add new entry
          entries = [entry, ...entries];
        }
        
        // Update mood streak
        let moodStreak = userProgress.moodStreak;
        const lastEntryDate = userProgress.moodEntries.length > 0 
          ? new Date(userProgress.moodEntries[0].date) 
          : undefined;
          
        if (!lastEntryDate || !isSameDay(lastEntryDate, today)) {
          moodStreak += 1;
        }
        
        // Update state
        set({
          userProgress: {
            ...userProgress,
            moodEntries: entries,
            moodStreak,
            lastActivity: new Date().toISOString(),
          }
        });
        
        // Update overall streak
        get().updateStreak();
      },
      
      completeGame: async (gameId: string) => {
        // Get current state
        const { userProgress } = get();
        
        // Update last activity timestamp
        set({
          userProgress: {
            ...userProgress,
            lastActivity: new Date().toISOString(),
          }
        });
        
        // Update overall streak
        get().updateStreak();
      },
      
      updateStreak: () => {
        const { userProgress } = get();
        const now = new Date();
        let newStreak = userProgress.streak;
        let isStreakUpdated = false;
        
        // Check if there's a last activity date
        if (userProgress.lastActivity) {
          const lastActivityDate = new Date(userProgress.lastActivity);
          
          // If last activity was today, no change to streak
          if (isSameDay(lastActivityDate, now)) {
            // No change to streak
          }
          // If last activity was yesterday, increment streak
          else if (isYesterday(lastActivityDate, now)) {
            newStreak += 1;
            isStreakUpdated = true;
          }
          // If last activity was before yesterday, reset streak to 1
          else {
            newStreak = 1;
            isStreakUpdated = true;
          }
        } else {
          // First activity ever
          newStreak = 1;
          isStreakUpdated = true;
        }
        
        // Update state if streak changed
        if (isStreakUpdated) {
          set({
            userProgress: {
              ...userProgress,
              streak: newStreak,
            }
          });
        }
      },
      
      resetProgress: () => {
        set({
          userProgress: {
            streak: 0,
            lastActivity: undefined,
            moodStreak: 0,
            journalStreak: 0,
            achievements: [],
            moodEntries: [],
            journalEntries: [],
          }
        });
      },
      
      getStreakInfo: () => {
        const { userProgress } = get();
        const lastActivity = userProgress.lastActivity;
        const currentStreak = userProgress.streak;
        
        // Check if this is a new streak day
        let isNewStreak = false;
        if (lastActivity) {
          const lastActivityDate = new Date(lastActivity);
          const today = new Date();
          
          // If last activity was yesterday, and this is the first activity today
          if (isYesterday(lastActivityDate, today)) {
            isNewStreak = true;
          }
          // If there was no activity in the last few days
          else if (!isSameDay(lastActivityDate, today)) {
            isNewStreak = true;
          }
        }
        
        return {
          current: currentStreak,
          lastActivity,
          isNewStreak
        };
      },
      
      // Error handling methods
      setError: (message: string | null) => {
        set({
          hasError: !!message,
          errorMessage: message
        });
      },
      
      clearError: () => {
        set({
          hasError: false,
          errorMessage: null
        });
      },
    }),
    {
      name: 'mental-app-storage',
    }
  )
);