import React, { useEffect } from 'react';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ThemeMode = 'light' | 'dark' | 'system';
export type ThemeColor = 'aqua' | 'blue' | 'purple' | 'green' | 'orange' | 'pink' | 'teal' | 'red' | 'indigo';
export type ThemeMood = 'calm' | 'energetic' | 'focused' | 'creative' | 'balanced';
export type AccessibilityPreset = 'none' | 'deuteranopia' | 'protanopia' | 'tritanopia' | 'high-contrast' | 'reduced-motion' | 'dyslexic';

// Define theme properties for different moods
const moodThemeMap: Record<ThemeMood, { color: ThemeColor, description: string }> = {
  calm: { 
    color: 'aqua', 
    description: 'A soothing theme to help you relax and reduce anxiety' 
  },
  energetic: { 
    color: 'orange', 
    description: 'A vibrant theme to boost energy and motivation' 
  },
  focused: { 
    color: 'purple', 
    description: 'A distraction-free theme to help with concentration' 
  },
  creative: { 
    color: 'pink', 
    description: 'An inspiring theme to encourage imagination and creativity' 
  },
  balanced: { 
    color: 'green', 
    description: 'A balanced theme for general wellbeing and harmony' 
  },
};

interface ThemeState {
  mode: ThemeMode;
  color: ThemeColor;
  mood: ThemeMood;
  autoAdjustWithMood: boolean;
  
  // Accessibility options
  accessibilityPreset: AccessibilityPreset;
  highContrast: boolean;
  reducedMotion: boolean;
  dyslexicFont: boolean;
  colorBlindMode: 'none' | 'deuteranopia' | 'protanopia' | 'tritanopia';
  largeText: boolean;
  
  // Theme attributes for SettingsPage
  theme: string; // Current theme mode as string for easier access
  
  // Theme actions
  setMode: (mode: ThemeMode) => void;
  setColor: (color: ThemeColor) => void;
  setMood: (mood: ThemeMood) => void;
  toggleAutoAdjust: () => void;
  toggleMode: () => void;
  setTheme: (theme: 'light' | 'dark') => void; // Simple theme setter
  
  // Accessibility actions
  setAccessibilityPreset: (preset: AccessibilityPreset) => void;
  toggleHighContrast: () => void;
  toggleReducedMotion: () => void;
  toggleDyslexicFont: () => void;
  setColorBlindMode: (mode: 'none' | 'deuteranopia' | 'protanopia' | 'tritanopia') => void;
  toggleLargeText: () => void;
  
  // CSS methods
  getPrimaryColor: () => string;
  getCssVariables: () => Record<string, string>;
  getMoodThemeInfo: () => { color: ThemeColor, description: string };
}

export const useTheme = create<ThemeState>()(
  persist(
    (set, get) => ({
      mode: 'light',
      color: 'aqua',
      mood: 'balanced',
      autoAdjustWithMood: true,
      theme: 'light', // Default theme for SettingsPage
      
      // Default accessibility settings
      accessibilityPreset: 'none',
      highContrast: false,
      reducedMotion: false,
      dyslexicFont: false,
      colorBlindMode: 'none',
      largeText: false,
      
      setMode: (mode: ThemeMode) => set({ mode }),
      
      setTheme: (theme: 'light' | 'dark') => {
        set({ theme, mode: theme });
        
        // Apply theme immediately
        const root = window.document.documentElement;
        root.classList.remove('light', 'dark');
        root.classList.add(theme);
        
        // Also reapply color variables for the new theme
        const cssVars = get().getCssVariables();
        Object.entries(cssVars).forEach(([key, value]) => {
          document.documentElement.style.setProperty(key, value);
        });
      },
      
      setColor: (color: ThemeColor) => {
        set({ color, autoAdjustWithMood: false });
        
        // Apply CSS variables immediately
        const cssVars = get().getCssVariables();
        Object.entries(cssVars).forEach(([key, value]) => {
          document.documentElement.style.setProperty(key, value);
        });
      },
      
      setMood: (mood: ThemeMood) => {
        const { autoAdjustWithMood } = get();
        
        if (autoAdjustWithMood) {
          const { color } = moodThemeMap[mood];
          set({ mood, color });
        } else {
          set({ mood });
        }
        
        // Apply CSS variables immediately
        const cssVars = get().getCssVariables();
        Object.entries(cssVars).forEach(([key, value]) => {
          document.documentElement.style.setProperty(key, value);
        });
      },
      
      toggleAutoAdjust: () => set(state => ({ autoAdjustWithMood: !state.autoAdjustWithMood })),
      
      toggleMode: () => {
        const { mode } = get();
        const newMode = mode === 'light' ? 'dark' : 'light';
        
        set({ 
          mode: newMode,
          theme: newMode
        });
        
        // Apply mode immediately
        const root = window.document.documentElement;
        root.classList.remove('light', 'dark');
        root.classList.add(newMode);
        
        // Also reapply color variables as they might have dark/light specific adjustments
        const cssVars = get().getCssVariables();
        Object.entries(cssVars).forEach(([key, value]) => {
          document.documentElement.style.setProperty(key, value);
        });
      },
      
      getPrimaryColor: () => {
        const { color } = get();
        switch (color) {
          case 'aqua': return 'hsl(187 52% 76%)';
          case 'blue': return 'hsl(221.2 83.2% 53.3%)';
          case 'purple': return 'hsl(262.1 83.3% 57.8%)';
          case 'green': return 'hsl(142.1 76.2% 36.3%)';
          case 'orange': return 'hsl(24.6 95% 53.1%)';
          case 'pink': return 'hsl(346.8 77.2% 49.8%)';
          case 'teal': return 'hsl(166 76.2% 36.3%)';
          case 'red': return 'hsl(0 84.2% 60.2%)';
          case 'indigo': return 'hsl(226 70% 40%)';
          default: return 'hsl(187 52% 76%)';
        }
      },
      
      getCssVariables: () => {
        const { color } = get();
        
        // Define colors for each theme
        // Define colors for both light and dark mode for each theme
        const colors = {
          aqua: {
            '--primary': 'hsl(187 52% 76%)',
            '--primary-foreground': 'hsl(222.2 47.4% 11.2%)',
            '--ring': 'hsl(187 52% 76%)',
            '--secondary': 'hsl(187 52% 60%)',
            '--accent': 'hsl(187 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          blue: {
            '--primary': 'hsl(221.2 83.2% 53.3%)',
            '--primary-foreground': 'hsl(210 40% 98%)',
            '--ring': 'hsl(221.2 83.2% 53.3%)',
            '--secondary': 'hsl(210 96% 54%)',
            '--accent': 'hsl(210 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          purple: {
            '--primary': 'hsl(262.1 83.3% 57.8%)',
            '--primary-foreground': 'hsl(210 40% 98%)',
            '--ring': 'hsl(262.1 83.3% 57.8%)',
            '--secondary': 'hsl(270 95% 75%)',
            '--accent': 'hsl(280 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          green: {
            '--primary': 'hsl(142.1 76.2% 45.3%)',
            '--primary-foreground': 'hsl(355.7 100% 97.3%)',
            '--ring': 'hsl(142.1 76.2% 45.3%)',
            '--secondary': 'hsl(160 84% 49%)',
            '--accent': 'hsl(140 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          orange: {
            '--primary': 'hsl(24.6 95% 53.1%)',
            '--primary-foreground': 'hsl(60 9.1% 97.8%)',
            '--ring': 'hsl(24.6 95% 53.1%)',
            '--secondary': 'hsl(35 91% 65%)',
            '--accent': 'hsl(30 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          pink: {
            '--primary': 'hsl(346.8 77.2% 49.8%)',
            '--primary-foreground': 'hsl(355.7 100% 97.3%)',
            '--ring': 'hsl(346.8 77.2% 49.8%)',
            '--secondary': 'hsl(336 80% 65%)',
            '--accent': 'hsl(340 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          teal: {
            '--primary': 'hsl(166 76.2% 40.3%)',
            '--primary-foreground': 'hsl(0 0% 100%)',
            '--ring': 'hsl(166 76.2% 40.3%)',
            '--secondary': 'hsl(180 70% 48%)',
            '--accent': 'hsl(170 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          red: {
            '--primary': 'hsl(0 84.2% 60.2%)',
            '--primary-foreground': 'hsl(0 0% 100%)',
            '--ring': 'hsl(0 84.2% 60.2%)',
            '--secondary': 'hsl(10 90% 70%)',
            '--accent': 'hsl(0 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
          indigo: {
            '--primary': 'hsl(226 70% 45%)',
            '--primary-foreground': 'hsl(0 0% 100%)',
            '--ring': 'hsl(226 70% 45%)',
            '--secondary': 'hsl(245 58% 51%)',
            '--accent': 'hsl(230 40% 96.1%)',
            '--accent-foreground': 'hsl(222.2 47.4% 11.2%)',
          },
        } as Record<ThemeColor, Record<string, string>>;
        
        return colors[color];
      },
      
      // Accessibility actions
      setAccessibilityPreset: (preset: AccessibilityPreset) => {
        if (preset === 'none') {
          set({ 
            accessibilityPreset: 'none',
            highContrast: false,
            reducedMotion: false,
            dyslexicFont: false,
            colorBlindMode: 'none',
            largeText: false
          });
        } else if (preset === 'high-contrast') {
          set({ 
            accessibilityPreset: preset,
            highContrast: true 
          });
        } else if (preset === 'reduced-motion') {
          set({ 
            accessibilityPreset: preset,
            reducedMotion: true 
          });
        } else if (preset === 'dyslexic') {
          set({ 
            accessibilityPreset: preset,
            dyslexicFont: true 
          });
        } else if (['deuteranopia', 'protanopia', 'tritanopia'].includes(preset)) {
          set({ 
            accessibilityPreset: preset,
            colorBlindMode: preset as 'deuteranopia' | 'protanopia' | 'tritanopia'
          });
        }
        
        // Apply accessibility settings immediately
        const root = window.document.documentElement;
        const { highContrast, reducedMotion, dyslexicFont, colorBlindMode, largeText } = get();
        
        // Apply classes based on settings
        root.classList.toggle('high-contrast', highContrast);
        root.classList.toggle('reduced-motion', reducedMotion);
        root.classList.toggle('dyslexic-font', dyslexicFont);
        root.classList.toggle('large-text', largeText);
        
        // Remove any existing color blind modes
        root.classList.remove('deuteranopia', 'protanopia', 'tritanopia');
        
        // Add the current color blind mode if set
        if (colorBlindMode !== 'none') {
          root.classList.add(colorBlindMode);
        }
      },
      
      toggleHighContrast: () => {
        const newValue = !get().highContrast;
        set({ 
          highContrast: newValue,
          accessibilityPreset: newValue ? 'high-contrast' : 'none'
        });
        
        // Apply immediately
        document.documentElement.classList.toggle('high-contrast', newValue);
      },
      
      toggleReducedMotion: () => {
        const newValue = !get().reducedMotion;
        set({ 
          reducedMotion: newValue,
          accessibilityPreset: newValue ? 'reduced-motion' : 'none'
        });
        
        // Apply immediately
        document.documentElement.classList.toggle('reduced-motion', newValue);
      },
      
      toggleDyslexicFont: () => {
        const newValue = !get().dyslexicFont;
        set({ 
          dyslexicFont: newValue,
          accessibilityPreset: newValue ? 'dyslexic' : 'none' 
        });
        
        // Apply immediately
        document.documentElement.classList.toggle('dyslexic-font', newValue);
      },
      
      setColorBlindMode: (mode: 'none' | 'deuteranopia' | 'protanopia' | 'tritanopia') => {
        set({ 
          colorBlindMode: mode,
          accessibilityPreset: mode !== 'none' ? mode as AccessibilityPreset : 'none'
        });
        
        // Apply immediately
        const root = document.documentElement;
        root.classList.remove('deuteranopia', 'protanopia', 'tritanopia');
        
        if (mode !== 'none') {
          root.classList.add(mode);
        }
      },
      
      toggleLargeText: () => {
        const newValue = !get().largeText;
        set({ largeText: newValue });
        
        // Apply immediately
        document.documentElement.classList.toggle('large-text', newValue);
      },
      
      getMoodThemeInfo: () => {
        const { mood } = get();
        return moodThemeMap[mood];
      },
    }),
    {
      name: 'mind-boost-theme',
    }
  )
);

// Hook to apply theme
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const { 
    mode, 
    getCssVariables, 
    highContrast, 
    reducedMotion, 
    dyslexicFont, 
    colorBlindMode, 
    largeText 
  } = useTheme();
  
  // Set initial mode class on document
  useEffect(() => {
    const root = window.document.documentElement;
    
    // Remove previous mode
    root.classList.remove('light', 'dark');
    
    // Add current mode
    if (mode === 'system') {
      const systemMode = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      root.classList.add(systemMode);
    } else {
      root.classList.add(mode);
    }
    
    // Apply CSS variables
    const cssVars = getCssVariables();
    Object.entries(cssVars).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value);
    });
    
    // Apply accessibility classes
    root.classList.toggle('high-contrast', highContrast);
    root.classList.toggle('reduced-motion', reducedMotion);
    root.classList.toggle('dyslexic-font', dyslexicFont);
    root.classList.toggle('large-text', largeText);
    
    // Remove any existing color blind modes
    root.classList.remove('deuteranopia', 'protanopia', 'tritanopia');
    
    // Add the current color blind mode if set
    if (colorBlindMode !== 'none') {
      root.classList.add(colorBlindMode);
    }
  }, [mode, getCssVariables, highContrast, reducedMotion, dyslexicFont, colorBlindMode, largeText]);
  
  return <>{children}</>;
}