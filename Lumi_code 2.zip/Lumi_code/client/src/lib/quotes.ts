export interface Quote {
  text: string;
  author: string;
  tags?: string[];
}

// A collection of uplifting and motivational quotes
export const quotes: Quote[] = [
  {
    text: "The only way to do great work is to love what you do.",
    author: "Steve Jobs",
    tags: ["work", "passion"]
  },
  {
    text: "Believe you can and you're halfway there.",
    author: "Theodore Roosevelt",
    tags: ["belief", "confidence"]
  },
  {
    text: "Your mind is a powerful thing. When you fill it with positive thoughts, your life will start to change.",
    author: "Unknown",
    tags: ["mindfulness", "positivity"]
  },
  {
    text: "The future belongs to those who believe in the beauty of their dreams.",
    author: "Eleanor Roosevelt",
    tags: ["dreams", "future"]
  },
  {
    text: "It always seems impossible until it's done.",
    author: "Nelson Mandela",
    tags: ["perseverance", "achievement"]
  },
  {
    text: "The only limit to our realization of tomorrow is our doubts of today.",
    author: "Franklin D. Roosevelt",
    tags: ["doubt", "potential"]
  },
  {
    text: "Don't watch the clock; do what it does. Keep going.",
    author: "Sam Levenson",
    tags: ["perseverance", "time"]
  },
  {
    text: "Everything you've ever wanted is on the other side of fear.",
    author: "George Addair",
    tags: ["fear", "courage"]
  },
  {
    text: "Happiness is not something ready-made. It comes from your own actions.",
    author: "Dalai Lama",
    tags: ["happiness", "action"]
  },
  {
    text: "You are never too old to set another goal or to dream a new dream.",
    author: "C.S. Lewis",
    tags: ["dreams", "goals", "age"]
  },
  {
    text: "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.",
    author: "Christian D. Larson",
    tags: ["self-belief", "obstacles"]
  },
  {
    text: "Your attitude, not your aptitude, will determine your altitude.",
    author: "Zig Ziglar",
    tags: ["attitude", "success"]
  },
  {
    text: "The only person you are destined to become is the person you decide to be.",
    author: "Ralph Waldo Emerson",
    tags: ["destiny", "choice"]
  },
  {
    text: "The greatest glory in living lies not in never falling, but in rising every time we fall.",
    author: "Nelson Mandela",
    tags: ["resilience", "failure"]
  },
  {
    text: "Life is 10% what happens to us and 90% how we react to it.",
    author: "Charles R. Swindoll",
    tags: ["reaction", "attitude"]
  },
  {
    text: "What you get by achieving your goals is not as important as what you become by achieving your goals.",
    author: "Zig Ziglar",
    tags: ["goals", "personal growth"]
  },
  {
    text: "I can't change the direction of the wind, but I can adjust my sails to always reach my destination.",
    author: "Jimmy Dean",
    tags: ["adaptability", "goals"]
  },
  {
    text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    author: "Winston Churchill",
    tags: ["success", "failure", "courage"]
  },
  {
    text: "Hardships often prepare ordinary people for an extraordinary destiny.",
    author: "C.S. Lewis",
    tags: ["hardship", "destiny"]
  },
  {
    text: "Start where you are. Use what you have. Do what you can.",
    author: "Arthur Ashe",
    tags: ["action", "beginning"]
  },
  {
    text: "The most wasted of all days is one without laughter.",
    author: "E.E. Cummings",
    tags: ["happiness", "laughter"]
  },
  {
    text: "You miss 100% of the shots you don't take.",
    author: "Wayne Gretzky",
    tags: ["action", "opportunity"]
  },
  {
    text: "The best way to predict the future is to create it.",
    author: "Abraham Lincoln",
    tags: ["future", "creation"]
  },
  {
    text: "Strive not to be a success, but rather to be of value.",
    author: "Albert Einstein",
    tags: ["success", "value"]
  },
  {
    text: "The mind is everything. What you think you become.",
    author: "Buddha",
    tags: ["mindfulness", "thought"]
  },
  {
    text: "Do what you can, with what you have, where you are.",
    author: "Theodore Roosevelt",
    tags: ["action", "resourcefulness"]
  },
  {
    text: "The journey of a thousand miles begins with one step.",
    author: "Lao Tzu",
    tags: ["beginning", "journey"]
  },
  {
    text: "It is never too late to be what you might have been.",
    author: "George Eliot",
    tags: ["potential", "change"]
  },
  {
    text: "The power of imagination makes us infinite.",
    author: "John Muir",
    tags: ["imagination", "possibility"]
  },
  {
    text: "The best dreams happen when you're awake.",
    author: "Cherie Gilderbloom",
    tags: ["dreams", "awareness"]
  }
];

/**
 * Get a random quote from the collection
 */
export function getRandomQuote(): Quote {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  return quotes[randomIndex];
}

/**
 * Get a quote for today (same quote for the whole day)
 */
export function getDailyQuote(): Quote {
  // Use the current date as a seed to get the same quote all day
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  
  // Use modulo to cycle through the quotes
  const index = dayOfYear % quotes.length;
  
  return quotes[index];
}

/**
 * Get quotes filtered by tags
 */
export function getQuotesByTags(filterTags: string[]): Quote[] {
  return quotes.filter(quote => {
    if (!quote.tags) return false;
    return filterTags.some(tag => quote.tags?.includes(tag));
  });
}