import { useState, useEffect, useMemo } from "react";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { MoodEntry } from "@/lib/types";

interface UseMoodTrackingReturn {
  moodEntries: MoodEntry[];
  addMoodEntry: (entry: MoodEntry) => Promise<void>;
  getMoodForDate: (date: Date) => MoodEntry | undefined;
  moodStats: Record<string, number>;
}

export function useMoodTracking(): UseMoodTrackingReturn {
  const { userProgress, addMoodEntry: addMoodEntryToStore } = useMentalApp();
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  
  // Initialize mood entries from userProgress
  useEffect(() => {
    if (userProgress?.moodEntries) {
      setMoodEntries(userProgress.moodEntries);
    }
  }, [userProgress]);
  
  // Calculate mood distribution stats
  const moodStats = useMemo(() => {
    const stats: Record<string, number> = {};
    
    moodEntries.forEach((entry) => {
      if (stats[entry.mood]) {
        stats[entry.mood] += 1;
      } else {
        stats[entry.mood] = 1;
      }
    });
    
    return stats;
  }, [moodEntries]);
  
  const addMoodEntry = async (entry: MoodEntry): Promise<void> => {
    return new Promise((resolve) => {
      // Add entry to Zustand store
      addMoodEntryToStore(entry);
      
      // Update local state
      const existingEntryIndex = moodEntries.findIndex(
        e => new Date(e.date).toDateString() === new Date(entry.date).toDateString()
      );
      
      if (existingEntryIndex >= 0) {
        // Replace existing entry
        const updatedEntries = [...moodEntries];
        updatedEntries[existingEntryIndex] = entry;
        setMoodEntries(updatedEntries);
      } else {
        // Add new entry
        setMoodEntries((prev) => [...prev, entry]);
      }
      
      resolve();
    });
  };
  
  const getMoodForDate = (date: Date): MoodEntry | undefined => {
    const dateString = date.toDateString();
    return moodEntries.find(
      entry => new Date(entry.date).toDateString() === dateString
    );
  };
  
  return {
    moodEntries,
    addMoodEntry,
    getMoodForDate,
    moodStats,
  };
}
