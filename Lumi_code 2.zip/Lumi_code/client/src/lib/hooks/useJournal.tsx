import { useState, useEffect } from "react";
import { useMentalApp } from "@/lib/stores/useMentalApp";
import { JournalEntry, JournalPrompt } from "@/lib/types";
import { getRandomPrompt } from "@/lib/prompts";

interface UseJournalReturn {
  entries: JournalEntry[];
  addEntry: (entry: JournalEntry) => Promise<void>;
  deleteEntry: (entryId: string) => void;
  currentPrompt: JournalPrompt | null;
  setCurrentPrompt: (prompt: JournalPrompt) => void;
}

export function useJournal(): UseJournalReturn {
  const { userProgress, addJournalEntry, deleteJournalEntry } = useMentalApp();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [currentPrompt, setCurrentPrompt] = useState<JournalPrompt | null>(null);
  
  // Initialize entries from userProgress
  useEffect(() => {
    if (userProgress?.journalEntries) {
      setEntries(userProgress.journalEntries);
    }
    
    // If no current prompt is set, get a random one
    if (!currentPrompt && userProgress) {
      setCurrentPrompt(getRandomPrompt("teen")); // Default to teen if not specified
    }
  }, [userProgress, currentPrompt]);
  
  const addEntry = async (entry: JournalEntry): Promise<void> => {
    return new Promise((resolve) => {
      // Add entry to Zustand store
      addJournalEntry(entry);
      
      // Update local state
      setEntries((prev) => [...prev, entry]);
      
      resolve();
    });
  };
  
  const deleteEntry = (entryId: string): void => {
    // Remove entry from local state
    setEntries((prev) => prev.filter((entry) => entry.id !== entryId));
    
    // Also remove it from the Zustand store
    deleteJournalEntry(entryId);
  };
  
  return {
    entries,
    addEntry,
    deleteEntry,
    currentPrompt,
    setCurrentPrompt,
  };
}
