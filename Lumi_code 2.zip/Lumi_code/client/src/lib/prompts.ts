import { JournalPrompt } from "./types";

// Journal prompts for different age groups
const childrenPrompts: JournalPrompt[] = [
  {
    id: "c1",
    text: "What made you smile today?",
    helpText: "Draw or write about something that made you happy."
  },
  {
    id: "c2",
    text: "If you were a superhero, what would your power be and how would you help people?",
    helpText: "Think about what special abilities you'd like to have!"
  },
  {
    id: "c3",
    text: "What's your favorite place in the world? Why do you like it?",
    helpText: "It could be somewhere you've been or somewhere you imagine."
  },
  {
    id: "c4",
    text: "What do you do when you feel sad? What helps you feel better?",
    helpText: "Everyone feels sad sometimes. What works for you?"
  },
  {
    id: "c5",
    text: "Write about someone who is kind to you. What do they do that's nice?",
    helpText: "This could be a friend, family member, teacher, or anyone else."
  },
  {
    id: "c6",
    text: "What's the coolest thing you learned recently?",
    helpText: "It could be from school, a book, or something you discovered yourself!"
  },
  {
    id: "c7",
    text: "What does being brave mean to you? Write about a time when you were brave.",
    helpText: "Being brave doesn't mean not being scared - it means doing something even when you are scared!"
  },
  {
    id: "c8",
    text: "If you could talk to animals, what would you ask them?",
    helpText: "Pick your favorite animal and imagine having a conversation."
  }
];

const teenPrompts: JournalPrompt[] = [
  {
    id: "t1",
    text: "What's something you're proud of accomplishing this week?",
    helpText: "It doesn't have to be a huge achievement - even small wins count!"
  },
  {
    id: "t2",
    text: "What's a challenge you're currently facing? What steps could you take to overcome it?",
    helpText: "Break down the problem and think about possible solutions."
  },
  {
    id: "t3",
    text: "Describe a person who inspires you. What qualities do they have that you admire?",
    helpText: "This could be someone you know personally or a public figure."
  },
  {
    id: "t4",
    text: "What are three things you're grateful for today?",
    helpText: "They can be big things or small everyday things you appreciate."
  },
  {
    id: "t5",
    text: "What do you do to relax when you're feeling stressed?",
    helpText: "Think about healthy coping strategies that work for you."
  },
  {
    id: "t6",
    text: "If you could change one thing about your school or community, what would it be and why?",
    helpText: "Think about how this change could make things better for everyone."
  },
  {
    id: "t7",
    text: "Write about a time when you felt really confident. What were you doing? How did it feel?",
    helpText: "Try to recall the details and the positive emotions you experienced."
  },
  {
    id: "t8",
    text: "What's a goal you have for the next few months? What steps will you take to achieve it?",
    helpText: "Setting specific, achievable steps can help you reach your goals."
  }
];

const youngAdultPrompts: JournalPrompt[] = [
  {
    id: "ya1",
    text: "Reflect on your personal growth over the past year. What positive changes have you noticed?",
    helpText: "Consider your relationships, habits, skills, or mindset."
  },
  {
    id: "ya2",
    text: "What are your core values? How do they guide your decisions and actions?",
    helpText: "Examples might include honesty, creativity, kindness, or independence."
  },
  {
    id: "ya3",
    text: "Describe a challenging situation you handled well recently. What strengths did you use?",
    helpText: "Think about the skills and personal qualities that helped you succeed."
  },
  {
    id: "ya4",
    text: "What does work-life balance mean to you? How are you maintaining it currently?",
    helpText: "Consider what changes might help you find more balance if needed."
  },
  {
    id: "ya5",
    text: "What self-care practices do you find most effective for your mental well-being?",
    helpText: "These could be physical, emotional, social, or spiritual practices."
  },
  {
    id: "ya6",
    text: "How do you handle criticism or feedback? What would you like to improve about your response?",
    helpText: "Constructive feedback can be valuable for growth, even when it's difficult to hear."
  },
  {
    id: "ya7",
    text: "What boundaries have you set in your relationships or work life? How have they helped you?",
    helpText: "Healthy boundaries protect your well-being and energy."
  },
  {
    id: "ya8",
    text: "Write about a fear or worry you're currently facing. What supports or resources could help?",
    helpText: "Naming our fears can sometimes help reduce their power over us."
  }
];

// Positive and negative thoughts for Mind Bubbles game
export const positiveThoughts = [
  "I can handle this challenge",
  "I am enough",
  "I believe in myself",
  "This is temporary",
  "I learn from mistakes",
  "I'm making progress",
  "Small steps matter",
  "I have strengths",
  "I can ask for help",
  "Today is a new day",
  "I am resilient",
  "I deserve happiness",
  "I have overcome before",
  "My effort counts",
  "I'm doing my best",
  "I can try again",
  "I have good qualities",
  "I am growing",
  "I am worthy",
  "I have supportive people"
];

export const negativeThoughts = [
  "I'm not good enough",
  "I always fail",
  "Nobody likes me",
  "I can't do anything right",
  "Everything is too hard",
  "This will never get better",
  "I'm so stupid",
  "Everyone is better than me",
  "It's all my fault",
  "I don't deserve good things",
  "I'll never succeed",
  "I'm a disappointment",
  "I'm too different",
  "I can't handle this",
  "What's the point in trying"
];

// Get random prompt based on age group
export function getRandomPrompt(ageGroup: string): JournalPrompt {
  let promptList: JournalPrompt[];
  
  if (ageGroup === "children") {
    promptList = childrenPrompts;
  } else if (ageGroup === "teen") {
    promptList = teenPrompts;
  } else {
    promptList = youngAdultPrompts;
  }
  
  const randomIndex = Math.floor(Math.random() * promptList.length);
  return promptList[randomIndex];
}

// Export all prompts for reference if needed
export const journalPrompts = {
  children: childrenPrompts,
  teen: teenPrompts,
  "young-adult": youngAdultPrompts
};
