import { Achievement } from "./types";

// Achievement data for the app
const achievements: Achievement[] = [
  {
    id: "streak-3",
    name: "Getting Started",
    description: "Used the app for 3 days in a row",
    criteria: "Complete any activity for 3 consecutive days",
    reward: "Unlocked new color theme",
    category: "streak"
  },
  {
    id: "streak-7",
    name: "Consistency Champion",
    description: "Used the app for 7 days in a row",
    criteria: "Complete any activity for 7 consecutive days",
    reward: "Unlocked special journal prompts",
    category: "streak"
  },
  {
    id: "streak-14",
    name: "Dedication Dynamo",
    description: "Used the app for 14 days in a row",
    criteria: "Complete any activity for 14 consecutive days",
    reward: "Unlocked expert-level games",
    category: "streak"
  },
  {
    id: "streak-30",
    name: "Mindfulness Master",
    description: "Used the app for 30 days in a row",
    criteria: "Complete any activity for 30 consecutive days",
    reward: "Unlocked all premium features",
    category: "streak"
  },
  {
    id: "all-games",
    name: "Game Master",
    description: "Played all the mental strength games",
    criteria: "Complete each of the four games at least once",
    reward: "+50 bonus points",
    category: "games"
  },
  {
    id: "journal-streak-3",
    name: "Reflective Writer",
    description: "Journaled for 3 days in a row",
    criteria: "Complete a journal entry for 3 consecutive days",
    reward: "Unlocked advanced prompts",
    category: "journal"
  },
  {
    id: "journal-streak-7",
    name: "Deep Thinker",
    description: "Journaled for 7 days in a row",
    criteria: "Complete a journal entry for 7 consecutive days",
    reward: "Unlocked journal insights",
    category: "journal"
  },
  {
    id: "mood-streak-3",
    name: "Emotion Tracker",
    description: "Tracked your mood for 3 days in a row",
    criteria: "Log your mood for 3 consecutive days",
    reward: "Unlocked mood insights",
    category: "mood"
  },
  {
    id: "mood-streak-7",
    name: "Emotion Expert",
    description: "Tracked your mood for 7 days in a row",
    criteria: "Log your mood for 7 consecutive days",
    reward: "Unlocked mood patterns chart",
    category: "mood"
  }
];

// Get all achievements
export function getAllAchievements(): Achievement[] {
  return achievements;
}

// Get achievements by category
export function getAchievementsByCategory(category: string): Achievement[] {
  return achievements.filter(achievement => achievement.category === category);
}

// Get achievement by ID
export function getAchievementById(id: string): Achievement | undefined {
  return achievements.find(achievement => achievement.id === id);
}

export default achievements;
